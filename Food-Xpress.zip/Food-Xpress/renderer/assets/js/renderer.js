// État global de l'application
let currentUser = null;
let currentPage = 'dashboard';
let sidebarCollapsed = false;
let companySettings = null;

// Initialisation au chargement
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Vérifier l'authentification
        const authResult = await window.api.checkAuth();
        if (!authResult.authenticated) {
            window.location.href = 'login.html';
            return;
        }
        
        currentUser = authResult.user;
        
        // Charger les paramètres de l'entreprise
        await loadCompanySettings();
        
        // Initialiser la sidebar
        initSidebar();
        
        // Mettre à jour l'interface
        updateUserInterface();
        
        // Charger la page appropriée
        const urlParams = new URLSearchParams(window.location.search);
        const page = urlParams.get('page') || 'dashboard';
        await loadPage(page);
        
        // Vérifier les sauvegardes
        checkBackupStatus();
        
        // Appliquer le thème
        applyTheme();
        
    } catch (error) {
        console.error('Erreur initialisation:', error);
        showNotification('Erreur de chargement de l\'application', 'danger');
    }
});

// Charger les paramètres de l'entreprise
async function loadCompanySettings() {
    try {
        const result = await window.api.getCompanySettings();
        if (result.success) {
            companySettings = result.data;
            updateLogo();
        }
    } catch (error) {
        console.error('Erreur chargement paramètres:', error);
    }
}

// Mettre à jour le logo
function updateLogo() {
    const logoIcon = document.getElementById('sidebarLogo');
    if (!logoIcon) return;
    
    if (companySettings && companySettings.logo) {
        // Si un logo personnalisé existe
        logoIcon.innerHTML = `<img src="../../${companySettings.logo}" alt="Logo" style="width: 32px; height: 32px; object-fit: contain;">`;
    } else {
        // Logo par défaut
        logoIcon.innerHTML = '<i class="fa fa-cutlery"></i>';
    }
}

// Mettre à jour l'interface avec les infos utilisateur
function updateUserInterface() {
    if (!currentUser) return;
    
    // Mettre à jour les éléments d'interface
    document.getElementById('userName').textContent = currentUser.nomComplet;
    document.getElementById('userRole').textContent = currentUser.role === 'admin' ? 'Administrateur' : 'Vendeur';
    
    // Avatar avec initiales
    const initials = currentUser.nomComplet
        .split(' ')
        .map(n => n[0])
        .join('')
        .toUpperCase()
        .substring(0, 2);
    document.getElementById('userAvatar').textContent = initials;
    
    // Cacher/Afficher les éléments réservés à l'admin
    if (currentUser.role !== 'admin') {
        document.querySelectorAll('.admin-only').forEach(el => {
            el.style.display = 'none';
        });
    }
}

// Initialiser la sidebar
function initSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const toggleBtn = document.querySelector('.toggle-btn');
    const toggleMobileBtn = document.querySelector('.toggle-btn-mobile');
    const navItems = document.querySelectorAll('.nav-item');
    
    // Restaurer l'état de la sidebar
    const savedState = localStorage.getItem('sidebarCollapsed');
    if (savedState === 'true') {
        sidebar.classList.add('collapsed');
        sidebarCollapsed = true;
    }
    
    // Toggle sidebar (desktop)
    toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        sidebarCollapsed = sidebar.classList.contains('collapsed');
        localStorage.setItem('sidebarCollapsed', sidebarCollapsed);
    });
    
    // Toggle sidebar (mobile)
    if (toggleMobileBtn) {
        toggleMobileBtn.addEventListener('click', () => {
            sidebar.classList.toggle('show');
        });
    }
    
    // Navigation
    navItems.forEach(item => {
        item.addEventListener('click', async (e) => {
            e.preventDefault();
            
            const page = item.dataset.page;
            if (!page) return;
            
            // Mettre à jour l'URL sans recharger
            const url = new URL(window.location);
            url.searchParams.set('page', page);
            window.history.pushState({}, '', url);
            
            // Mettre à jour l'état actif
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            
            // Charger la page
            currentPage = page;
            await loadPage(page);
            
            // Sur mobile, fermer la sidebar
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('show');
            }
        });
    });
    
    // Marquer l'élément actif initial
    const activeItem = document.querySelector(`.nav-item[data-page="${currentPage}"]`);
    if (activeItem) {
        activeItem.classList.add('active');
    }
    
    // Gestion du menu utilisateur
    const userInfo = document.getElementById('userInfo');
    const userMenu = document.getElementById('userMenu');
    
    userInfo.addEventListener('click', (e) => {
        e.stopPropagation();
        const rect = userInfo.getBoundingClientRect();
        userMenu.style.top = rect.bottom + 5 + 'px';
        userMenu.style.left = rect.right - 200 + 'px';
        userMenu.style.display = userMenu.style.display === 'none' ? 'block' : 'none';
    });
    
    document.addEventListener('click', () => {
        userMenu.style.display = 'none';
    });
}

// Charger une page
async function loadPage(page) {
    const contentArea = document.getElementById('contentArea');
    if (!contentArea) return;
    
    // Afficher un loader
    contentArea.innerHTML = `
        <div class="loader-container" style="display: flex; justify-content: center; align-items: center; height: 400px;">
            <div class="loader"></div>
        </div>
    `;
    
    // Mettre à jour le titre de la page
    updatePageTitle(page);
    
    try {
        // Charger le contenu de la page
        const response = await fetch(`pages/${page}.html`);
        if (!response.ok) throw new Error('Page non trouvée');
        
        const html = await response.text();
        contentArea.innerHTML = html;
        
        // Charger le script spécifique à la page
        await loadPageScript(page);
        
        // Initialiser la page si la fonction existe
        if (window.initPage) {
            window.initPage();
        }
        
        // Appliquer les styles Bootstrap aux nouveaux éléments
        applyBootstrapStyles();
        
    } catch (error) {
        console.error('Erreur chargement page:', error);
        contentArea.innerHTML = `
            <div class="container mt-5">
                <div class="alert alert-danger">
                    <i class="fa fa-exclamation-circle"></i>
                    Erreur de chargement de la page
                </div>
                <button class="btn btn-primary" onclick="window.api.navigate('dashboard')">
                    <i class="fa fa-home"></i> Retour au tableau de bord
                </button>
            </div>
        `;
    }
}

// Mettre à jour le titre de la page
function updatePageTitle(page) {
    const titles = {
        'dashboard': 'Tableau de bord',
        'new-sale': 'Nouvelle vente',
        'invoices': 'Factures',
        'products': 'Produits',
        'inventory': 'Inventaire',
        'purchases': 'Achats fournisseurs',
        'users': 'Utilisateurs',
        'backup': 'Sauvegarde',
        'settings': 'Paramètres',
        'help': 'Aide',
        'contact': 'Nous contacter',
        'licence': 'Licence'
    };
    
    const titleElement = document.getElementById('pageTitle');
    if (titleElement) {
        titleElement.textContent = titles[page] || 'FOOD XPRESS';
    }
}

// Charger le script d'une page
async function loadPageScript(page) {
    return new Promise((resolve, reject) => {
        // Vérifier si le script est déjà chargé
        const existingScript = document.querySelector(`script[src="../assets/js/pages/${page}.js"]`);
        if (existingScript) {
            existingScript.remove();
        }
        
        const script = document.createElement('script');
        script.src = `../assets/js/pages/${page}.js?t=${Date.now()}`; // Cache busting
        script.onload = resolve;
        script.onerror = reject;
        document.body.appendChild(script);
    });
}

// Vérifier le statut des sauvegardes
async function checkBackupStatus() {
    try {
        const result = await window.api.getBackupInfo();
        if (result.success && result.needsBackup) {
            showNotification('Aucune sauvegarde effectuée depuis plus de 7 jours', 'warning', 10000);
        }
    } catch (error) {
        console.error('Erreur vérification sauvegarde:', error);
    }
}

// Afficher une notification
function showNotification(message, type = 'info', duration = 5000) {
    // Créer l'élément de notification
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} notification-toast`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        max-width: 400px;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease;
        display: flex;
        align-items: center;
        gap: 10px;
    `;
    
    const icons = {
        success: 'fa-check-circle',
        danger: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    notification.innerHTML = `
        <i class="fa ${icons[type] || icons.info} fa-lg"></i>
        <div style="flex: 1;">${message}</div>
        <button class="btn-close btn-sm" onclick="this.parentElement.remove()"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Supprimer après la durée spécifiée
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, duration);
}

// Appliquer les styles Bootstrap
function applyBootstrapStyles() {
    // Activer tous les tooltips Bootstrap
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Activer tous les popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}

// Appliquer le thème
function applyTheme() {
    // Ajouter les animations CSS si elles n'existent pas
    if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
            
            .notification-toast {
                margin-bottom: 10px;
            }
            
            .notification-toast:hover {
                transform: translateX(-5px);
                box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            }
            
            /* Style pour les cartes */
            .card {
                transition: transform 0.2s, box-shadow 0.2s;
            }
            
            .card:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            }
            
            /* Style pour les boutons */
            .btn {
                transition: all 0.2s;
            }
            
            .btn:hover {
                transform: translateY(-1px);
            }
            
            /* Style pour les tableaux */
            .table-hover tbody tr:hover {
                background-color: rgba(102, 126, 234, 0.05);
                cursor: pointer;
            }
            
            /* Badges personnalisés */
            .badge-success {
                background: #c6f6d5;
                color: #22543d;
            }
            
            .badge-warning {
                background: #feebc8;
                color: #744210;
            }
            
            .badge-danger {
                background: #fed7d7;
                color: #742a2a;
            }
            
            .badge-info {
                background: #bee3f8;
                color: #2c5282;
            }
            
            /* Loader personnalisé */
            .loader {
                border: 4px solid #f3f3f3;
                border-top: 4px solid #667eea;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                animation: spin 1s linear infinite;
            }
            
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
    }
}

// Fonctions de navigation
function showProfile() {
    showNotification('Profil - Fonctionnalité à venir', 'info');
}

// Déconnexion
async function logout() {
    try {
        await window.api.logout();
        window.location.href = 'login.html';
    } catch (error) {
        console.error('Erreur déconnexion:', error);
    }
}

// Rendre les fonctions globales disponibles
window.showNotification = showNotification;
window.logout = logout;