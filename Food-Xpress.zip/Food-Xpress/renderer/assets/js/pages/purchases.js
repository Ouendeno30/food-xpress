let purchasesData = [];
let suppliersData = [];
let productsData = [];
let purchaseCart = [];
let selectedPurchaseProduct = null;
let purchaseQuantityModal = null;
let purchaseModal = null;
let suppliersModal = null;
let supplierFormModal = null;

// Initialisation de la page
window.initPage = function() {
    purchaseQuantityModal = new bootstrap.Modal(document.getElementById('purchaseQuantityModal'));
    purchaseModal = new bootstrap.Modal(document.getElementById('purchaseModal'));
    suppliersModal = new bootstrap.Modal(document.getElementById('suppliersModal'));
    supplierFormModal = new bootstrap.Modal(document.getElementById('supplierFormModal'));
    
    loadSuppliers();
    loadProducts();
    loadPurchases();
    initFilters();
};

// Charger les fournisseurs
async function loadSuppliers() {
    try {
        const result = await window.api.getSuppliers();
        if (result.success) {
            suppliersData = result.data;
            displaySuppliers();
            loadSuppliersSelect();
        }
    } catch (error) {
        console.error('Erreur chargement fournisseurs:', error);
    }
}

// Charger les produits
async function loadProducts() {
    try {
        const result = await window.api.getProducts();
        if (result.success) {
            productsData = result.data;
        }
    } catch (error) {
        console.error('Erreur chargement produits:', error);
    }
}

// Charger les achats
async function loadPurchases() {
    try {
        const filters = getFilters();
        const result = await window.api.getPurchases(filters);
        
        if (result.success) {
            purchasesData = result.data;
            displayPurchases(purchasesData);
            updateStatistics(purchasesData);
        }
    } catch (error) {
        console.error('Erreur chargement achats:', error);
        showNotification('Erreur de chargement', 'danger');
    }
}

// Afficher les achats
function displayPurchases(purchases) {
    const tbody = document.getElementById('purchasesTableBody');
    
    if (!purchases || purchases.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="text-center py-4">
                    <i class="fa fa-truck fa-3x text-muted mb-3"></i>
                    <p>Aucun achat trouvé</p>
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    purchases.forEach(p => {
        const date = new Date(p.date_achat).toLocaleString('fr-FR');
        
        html += `
            <tr>
                <td><code>${p.numero_achat}</code></td>
                <td>${date}</td>
                <td>${escapeHtml(p.fournisseur_nom || 'Fournisseur inconnu')}</td>
                <td>${escapeHtml(p.reference_bl || '-')}</td>
                <td>${p.nombre_lignes || 0}</td>
                <td class="fw-bold">${formatPrice(p.montant_total)}</td>
                <td>${escapeHtml(p.utilisateur_nom)}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-info" onclick="showPurchaseDetails(${p.id})"
                                title="Détails">
                            <i class="fa fa-info-circle"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Afficher les fournisseurs
function displaySuppliers() {
    const tbody = document.getElementById('suppliersTableBody');
    
    if (!suppliersData || suppliersData.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center">Aucun fournisseur</td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    suppliersData.forEach(s => {
        html += `
            <tr>
                <td>${escapeHtml(s.nom)}</td>
                <td>${escapeHtml(s.telephone || '-')}</td>
                <td>${s.nombre_achats || 0}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary" onclick="editSupplier(${s.id})">
                            <i class="fa fa-edit"></i>
                        </button>
                        <button class="btn btn-outline-danger" onclick="deleteSupplier(${s.id})" 
                                ${s.nombre_achats > 0 ? 'disabled' : ''}>
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Charger les fournisseurs dans le select
function loadSuppliersSelect() {
    const select = document.getElementById('purchaseFournisseur');
    const filterSelect = document.getElementById('filterFournisseur');
    
    let options = '<option value="">Sélectionner un fournisseur</option>';
    let filterOptions = '<option value="">Tous les fournisseurs</option>';
    
    suppliersData.forEach(s => {
        options += `<option value="${s.id}">${escapeHtml(s.nom)}</option>`;
        filterOptions += `<option value="${s.id}">${escapeHtml(s.nom)}</option>`;
    });
    
    select.innerHTML = options;
    filterSelect.innerHTML = filterOptions;
}

// Mettre à jour les statistiques
function updateStatistics(purchases) {
    const total = purchases.length;
    const amount = purchases.reduce((sum, p) => sum + p.montant_total, 0);
    const avg = total > 0 ? amount / total : 0;
    
    document.getElementById('totalPurchases').textContent = total;
    document.getElementById('totalAmount').textContent = formatPrice(amount);
    document.getElementById('averageAmount').textContent = formatPrice(avg);
}

// Rechercher des produits pour l'achat
function searchPurchaseProducts() {
    const query = document.getElementById('purchaseProductSearch').value.toLowerCase();
    const resultsDiv = document.getElementById('purchaseSearchResults');
    
    if (query.length < 2) {
        resultsDiv.innerHTML = '';
        return;
    }
    
    const filtered = productsData.filter(p => 
        p.nom.toLowerCase().includes(query) || 
        p.reference.toLowerCase().includes(query)
    ).slice(0, 10);
    
    if (filtered.length === 0) {
        resultsDiv.innerHTML = '<div class="list-group-item text-muted">Aucun produit trouvé</div>';
        return;
    }
    
    let html = '';
    filtered.forEach(p => {
        html += `
            <div class="list-group-item list-group-item-action" 
                 onclick="selectPurchaseProduct(${p.id})">
                <div class="d-flex justify-content-between">
                    <div>
                        <strong>${escapeHtml(p.nom)}</strong>
                        <br>
                        <small>Stock: ${p.stock_actuel} ${p.unite}</small>
                    </div>
                    <div class="text-end">
                        <small>Prix achat: ${formatPrice(p.prix_achat)}</small>
                    </div>
                </div>
            </div>
        `;
    });
    
    resultsDiv.innerHTML = html;
}

// Sélectionner un produit pour l'achat
function selectPurchaseProduct(productId) {
    selectedPurchaseProduct = productsData.find(p => p.id == productId);
    if (!selectedPurchaseProduct) return;
    
    document.getElementById('purchaseSelectedProductName').textContent = selectedPurchaseProduct.nom;
    document.getElementById('purchaseQuantity').value = 1;
    document.getElementById('purchaseUnitPrice').value = selectedPurchaseProduct.prix_achat;
    
    // Effacer la recherche
    document.getElementById('purchaseProductSearch').value = '';
    document.getElementById('purchaseSearchResults').innerHTML = '';
    
    purchaseQuantityModal.show();
}

// Ajouter au panier d'achat
function addToPurchaseCart() {
    const quantity = parseFloat(document.getElementById('purchaseQuantity').value);
    const unitPrice = parseFloat(document.getElementById('purchaseUnitPrice').value);
    
    if (isNaN(quantity) || quantity <= 0) {
        showNotification('Quantité invalide', 'warning');
        return;
    }
    
    if (isNaN(unitPrice) || unitPrice < 0) {
        showNotification('Prix invalide', 'warning');
        return;
    }
    
    // Vérifier si le produit est déjà dans le panier
    const existingItem = purchaseCart.find(item => item.produit_id === selectedPurchaseProduct.id);
    
    if (existingItem) {
        existingItem.quantite += quantity;
        existingItem.prix_unitaire = unitPrice; // Mettre à jour avec le nouveau prix
        existingItem.montant = existingItem.quantite * existingItem.prix_unitaire;
    } else {
        purchaseCart.push({
            produit_id: selectedPurchaseProduct.id,
            nom: selectedPurchaseProduct.nom,
            quantite: quantity,
            prix_unitaire: unitPrice,
            montant: quantity * unitPrice,
            unite: selectedPurchaseProduct.unite
        });
    }
    
    purchaseQuantityModal.hide();
    updatePurchaseCartDisplay();
}

// Mettre à jour l'affichage du panier d'achat
function updatePurchaseCartDisplay() {
    const tbody = document.getElementById('purchaseCartTableBody');
    const totalElement = document.getElementById('purchaseTotal');
    
    if (purchaseCart.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-3 text-muted">
                    Aucun produit ajouté
                </td>
            </tr>
        `;
        totalElement.textContent = formatPrice(0);
        return;
    }
    
    let html = '';
    let total = 0;
    
    purchaseCart.forEach((item, index) => {
        total += item.montant;
        html += `
            <tr>
                <td>${escapeHtml(item.nom)}</td>
                <td>${item.quantite} ${item.unite}</td>
                <td>${formatPrice(item.prix_unitaire)}</td>
                <td>${formatPrice(item.montant)}</td>
                <td>
                    <button class="btn btn-sm btn-danger" onclick="removeFromPurchaseCart(${index})">
                        <i class="fa fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    totalElement.textContent = formatPrice(total);
}

// Retirer du panier d'achat
function removeFromPurchaseCart(index) {
    purchaseCart.splice(index, 1);
    updatePurchaseCartDisplay();
}

// Afficher le modal d'ajout d'achat
function showAddPurchaseModal() {
    purchaseCart = [];
    document.getElementById('purchaseFournisseur').value = '';
    document.getElementById('purchaseReferenceBL').value = '';
    document.getElementById('purchaseNote').value = '';
    updatePurchaseCartDisplay();
    purchaseModal.show();
}

// Sauvegarder l'achat
async function savePurchase() {
    if (purchaseCart.length === 0) {
        showNotification('Ajoutez au moins un produit', 'warning');
        return;
    }
    
    const fournisseurId = document.getElementById('purchaseFournisseur').value;
    if (!fournisseurId) {
        showNotification('Sélectionnez un fournisseur', 'warning');
        return;
    }
    
    const total = purchaseCart.reduce((sum, item) => sum + item.montant, 0);
    
    const purchaseData = {
        fournisseur_id: fournisseurId,
        reference_bl: document.getElementById('purchaseReferenceBL').value.trim() || null,
        note: document.getElementById('purchaseNote').value.trim() || null,
        items: purchaseCart.map(item => ({
            produit_id: item.produit_id,
            quantite: item.quantite,
            prix_unitaire: item.prix_unitaire,
            montant: item.montant
        })),
        montant_total: total
    };
    
    try {
        const saveBtn = document.getElementById('savePurchaseBtn');
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Enregistrement...';
        
        const result = await window.api.createPurchase(purchaseData);
        
        if (result.success) {
            showNotification('Achat enregistré avec succès', 'success');
            purchaseModal.hide();
            purchaseCart = [];
            loadPurchases();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de l\'enregistrement', 'danger');
    } finally {
        const saveBtn = document.getElementById('savePurchaseBtn');
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fa fa-save"></i> Enregistrer l\'achat';
    }
}

// Afficher les détails d'un achat
async function showPurchaseDetails(id) {
    try {
        const result = await window.api.getPurchase(id);
        if (result.success) {
            const purchase = result.data;
            
            let details = `ACHAT ${purchase.numero_achat}\n`;
            details += `Date: ${new Date(purchase.date_achat).toLocaleString('fr-FR')}\n`;
            details += `Fournisseur: ${purchase.fournisseur_nom || 'Non spécifié'}\n`;
            details += `Réf. BL: ${purchase.reference_bl || '-'}\n`;
            details += `Saisi par: ${purchase.utilisateur_nom}\n\n`;
            details += 'PRODUITS ACHETÉS:\n';
            details += '-'.repeat(50) + '\n';
            
            purchase.lignes.forEach(ligne => {
                details += `${ligne.produit_nom}\n`;
                details += `  ${ligne.quantite} ${ligne.unite} x ${formatPrice(ligne.prix_achat_unitaire)} = ${formatPrice(ligne.montant_ligne)}\n`;
            });
            
            details += '-'.repeat(50) + '\n';
            details += `TOTAL: ${formatPrice(purchase.montant_total)}\n`;
            
            if (purchase.note) {
                details += `\nNote: ${purchase.note}`;
            }
            
            alert(details);
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Impossible de charger les détails', 'danger');
    }
}

// Gestion des fournisseurs
function showAddSupplierModal() {
    document.getElementById('supplierModalTitle').textContent = 'Nouveau fournisseur';
    document.getElementById('supplierForm').reset();
    document.getElementById('supplierId').value = '';
    supplierFormModal.show();
}

function editSupplier(id) {
    const supplier = suppliersData.find(s => s.id == id);
    if (!supplier) return;
    
    document.getElementById('supplierModalTitle').textContent = 'Modifier fournisseur';
    document.getElementById('supplierId').value = supplier.id;
    document.getElementById('supplierNom').value = supplier.nom;
    document.getElementById('supplierTelephone').value = supplier.telephone || '';
    document.getElementById('supplierAdresse').value = supplier.adresse || '';
    
    supplierFormModal.show();
}

async function saveSupplier() {
    const id = document.getElementById('supplierId').value;
    const nom = document.getElementById('supplierNom').value.trim();
    
    if (!nom) {
        showNotification('Le nom du fournisseur est obligatoire', 'warning');
        return;
    }
    
    const supplierData = {
        id: id || undefined,
        nom: nom,
        telephone: document.getElementById('supplierTelephone').value.trim() || null,
        adresse: document.getElementById('supplierAdresse').value.trim() || null
    };
    
    try {
        let result;
        if (id) {
            result = await window.api.updateSupplier(supplierData);
        } else {
            result = await window.api.createSupplier(supplierData);
        }
        
        if (result.success) {
            showNotification(result.message, 'success');
            supplierFormModal.hide();
            await loadSuppliers();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la sauvegarde', 'danger');
    }
}

async function deleteSupplier(id) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce fournisseur ?')) {
        return;
    }
    
    try {
        const result = await window.api.deleteSupplier(id);
        if (result.success) {
            showNotification('Fournisseur supprimé', 'success');
            await loadSuppliers();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la suppression', 'danger');
    }
}

// Fonctions utilitaires
function getFilters() {
    return {
        date_debut: document.getElementById('filterDateDebut').value,
        date_fin: document.getElementById('filterDateFin').value,
        fournisseur_id: document.getElementById('filterFournisseur').value || null
    };
}

function applyFilters() {
    loadPurchases();
}

function initFilters() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('filterDateDebut').value = today;
    document.getElementById('filterDateFin').value = today;
}

function clearProductSearch() {
    document.getElementById('purchaseProductSearch').value = '';
    document.getElementById('purchaseSearchResults').innerHTML = '';
}

function formatPrice(price) {
    return new Intl.NumberFormat('fr-GN', {
        style: 'currency',
        currency: 'GNF',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(price);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}