let invoicesData = [];
let usersData = [];

// Initialisation de la page
window.initPage = function() {
    loadUsers();
    loadInvoices();
    initFilters();
};

// Charger les utilisateurs pour le filtre
async function loadUsers() {
    try {
        const result = await window.api.getUsers();
        if (result.success) {
            usersData = result.data;
            const select = document.getElementById('filterVendeur');
            usersData.forEach(user => {
                select.innerHTML += `<option value="${user.id}">${escapeHtml(user.nom_complet)}</option>`;
            });
        }
    } catch (error) {
        console.error('Erreur chargement utilisateurs:', error);
    }
}

// Charger les factures
async function loadInvoices() {
    try {
        const filters = getFilters();
        const result = await window.api.getSales(filters);
        
        if (result.success) {
            invoicesData = result.data;
            displayInvoices(invoicesData);
            updateSummary(invoicesData);
        }
    } catch (error) {
        console.error('Erreur chargement factures:', error);
        showNotification('Erreur de chargement', 'danger');
    }
}

// Afficher les factures
function displayInvoices(invoices) {
    const tbody = document.getElementById('invoicesTableBody');
    
    if (!invoices || invoices.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="text-center py-4">
                    <i class="fa fa-file-text-o fa-3x text-muted mb-3"></i>
                    <p>Aucune facture trouvée</p>
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    invoices.forEach(inv => {
        const date = new Date(inv.date_vente).toLocaleString('fr-FR');
        
        html += `
            <tr>
                <td><code>${inv.numero_facture}</code></td>
                <td>${date}</td>
                <td>${escapeHtml(inv.client_nom || 'Client divers')}</td>
                <td>${escapeHtml(inv.vendeur_nom)}</td>
                <td>${inv.nombre_articles || 0}</td>
                <td class="fw-bold">${formatPrice(inv.montant_total)}</td>
                <td>
                    ${inv.pdf_path ? 
                        '<span class="badge badge-success">Générée</span>' : 
                        '<span class="badge badge-warning">En attente</span>'}
                </td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary" onclick="viewInvoice(${inv.id})"
                                title="Voir la facture">
                            <i class="fa fa-eye"></i>
                        </button>
                        <button class="btn btn-outline-success" onclick="printInvoice(${inv.id})"
                                title="Imprimer">
                            <i class="fa fa-print"></i>
                        </button>
                        <button class="btn btn-outline-info" onclick="showInvoiceDetails(${inv.id})"
                                title="Détails">
                            <i class="fa fa-info-circle"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Mettre à jour le résumé
function updateSummary(invoices) {
    const total = invoices.reduce((sum, inv) => sum + inv.montant_total, 0);
    const avg = invoices.length > 0 ? total / invoices.length : 0;
    
    document.getElementById('totalInvoices').textContent = invoices.length;
    document.getElementById('totalRevenue').textContent = formatPrice(total);
    document.getElementById('averageCart').textContent = formatPrice(avg);
}

// Obtenir les filtres
function getFilters() {
    return {
        date_debut: document.getElementById('filterDateDebut').value,
        date_fin: document.getElementById('filterDateFin').value,
        utilisateur_id: document.getElementById('filterVendeur').value || null
    };
}

// Appliquer les filtres
function applyFilters() {
    loadInvoices();
}

// Rafraîchir
function refreshInvoices() {
    loadInvoices();
}

// Voir une facture
async function viewInvoice(id) {
    try {
        await window.api.openInvoice(id);
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Impossible d\'ouvrir la facture', 'danger');
    }
}

// Imprimer une facture
async function printInvoice(id) {
    try {
        await window.api.openInvoice(id);
        // La fonction d'impression native du visualiseur PDF sera utilisée
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Impossible d\'imprimer la facture', 'danger');
    }
}

// Afficher les détails d'une facture
async function showInvoiceDetails(id) {
    try {
        const result = await window.api.getSale(id);
        if (result.success) {
            const invoice = result.data;
            
            let details = `FACTURE ${invoice.numero_facture}\n`;
            details += `Date: ${new Date(invoice.date_vente).toLocaleString('fr-FR')}\n`;
            details += `Client: ${invoice.client_nom || 'Client divers'}\n`;
            details += `Vendeur: ${invoice.vendeur_nom}\n\n`;
            details += 'DÉTAIL DES ARTICLES:\n';
            details += '-'.repeat(50) + '\n';
            
            invoice.lignes.forEach(ligne => {
                details += `${ligne.produit_nom}\n`;
                details += `  ${ligne.quantite} ${ligne.unite} x ${formatPrice(ligne.prix_vente_unitaire)} = ${formatPrice(ligne.montant_ligne)}\n`;
            });
            
            details += '-'.repeat(50) + '\n';
            details += `TOTAL: ${formatPrice(invoice.montant_total)}\n`;
            details += `Payé: ${formatPrice(invoice.montant_paye)}\n`;
            details += `Monnaie: ${formatPrice(invoice.monnaie_rendue)}`;
            
            alert(details);
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Impossible de charger les détails', 'danger');
    }
}

// Initialiser les filtres avec la date du jour
function initFilters() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('filterDateDebut').value = today;
    document.getElementById('filterDateFin').value = today;
}

// Formater le prix
function formatPrice(price) {
    return new Intl.NumberFormat('fr-GN', {
        style: 'currency',
        currency: 'GNF',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(price);
}

// Échapper le HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}