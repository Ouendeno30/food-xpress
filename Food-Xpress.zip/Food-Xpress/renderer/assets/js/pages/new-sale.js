let cart = [];
let selectedProduct = null;
let productsCache = [];
let quantityModal = null;

// Initialisation de la page
window.initPage = function() {
    quantityModal = new bootstrap.Modal(document.getElementById('quantityModal'));
    loadProducts();
    updateCartDisplay();
};

// Charger les produits
async function loadProducts() {
    try {
        const result = await window.api.getProducts();
        if (result.success) {
            productsCache = result.data;
        }
    } catch (error) {
        console.error('Erreur chargement produits:', error);
        showNotification('Erreur de chargement des produits', 'danger');
    }
}

// Rechercher des produits
async function searchProducts() {
    const query = document.getElementById('productSearch').value.trim();
    const resultsDiv = document.getElementById('searchResults');
    
    if (query.length < 2) {
        resultsDiv.innerHTML = `
            <div class="text-center text-muted py-4">
                <i class="fa fa-search fa-3x mb-3"></i>
                <p>Commencez à taper pour rechercher...</p>
            </div>
        `;
        return;
    }
    
    try {
        const result = await window.api.searchProducts(query);
        if (result.success) {
            displaySearchResults(result.data);
        }
    } catch (error) {
        console.error('Erreur recherche:', error);
    }
}

// Afficher les résultats de recherche
function displaySearchResults(products) {
    const resultsDiv = document.getElementById('searchResults');
    
    if (products.length === 0) {
        resultsDiv.innerHTML = `
            <div class="text-center text-muted py-4">
                <i class="fa fa-exclamation-circle fa-3x mb-3"></i>
                <p>Aucun produit trouvé</p>
            </div>
        `;
        return;
    }
    
    let html = '<div class="list-group">';
    products.forEach(product => {
        const stockClass = product.stock_actuel <= 0 ? 'text-danger' : 
                          product.stock_actuel < product.seuil_alerte ? 'text-warning' : 'text-success';
        
        html += `
            <div class="list-group-item list-group-item-action" 
                 onclick="selectProduct(${product.id})"
                 style="cursor: pointer;">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <strong>${escapeHtml(product.nom)}</strong>
                        <br>
                        <small class="text-muted">Ref: ${product.reference}</small>
                    </div>
                    <div class="text-end">
                        <div class="fw-bold">${formatPrice(product.prix_vente)}</div>
                        <small class="${stockClass}">
                            Stock: ${product.stock_actuel} ${product.unite}
                        </small>
                    </div>
                </div>
            </div>
        `;
    });
    html += '</div>';
    
    resultsDiv.innerHTML = html;
}

// Sélectionner un produit
function selectProduct(productId) {
    selectedProduct = productsCache.find(p => p.id == productId);
    if (!selectedProduct) return;
    
    if (selectedProduct.stock_actuel <= 0) {
        showNotification('Produit en rupture de stock', 'danger');
        return;
    }
    
    document.getElementById('selectedProductName').textContent = selectedProduct.nom;
    document.getElementById('productQuantity').value = 1;
    document.getElementById('productQuantity').max = selectedProduct.stock_actuel;
    document.getElementById('stockDisponible').textContent = 
        `Stock disponible: ${selectedProduct.stock_actuel} ${selectedProduct.unite}`;
    
    quantityModal.show();
}

// Ajouter au panier
function addToCart() {
    const quantity = parseFloat(document.getElementById('productQuantity').value);
    
    if (isNaN(quantity) || quantity <= 0) {
        showNotification('Quantité invalide', 'warning');
        return;
    }
    
    if (quantity > selectedProduct.stock_actuel) {
        showNotification('Quantité supérieure au stock disponible', 'danger');
        return;
    }
    
    // Vérifier si le produit est déjà dans le panier
    const existingItem = cart.find(item => item.produit_id === selectedProduct.id);
    
    if (existingItem) {
        const newQuantity = existingItem.quantite + quantity;
        if (newQuantity > selectedProduct.stock_actuel) {
            showNotification('Quantité totale supérieure au stock disponible', 'danger');
            return;
        }
        existingItem.quantite = newQuantity;
        existingItem.montant = existingItem.quantite * existingItem.prix_unitaire;
    } else {
        cart.push({
            produit_id: selectedProduct.id,
            nom: selectedProduct.nom,
            quantite: quantity,
            prix_unitaire: selectedProduct.prix_vente,
            montant: quantity * selectedProduct.prix_vente,
            unite: selectedProduct.unite,
            stock_max: selectedProduct.stock_actuel
        });
    }
    
    quantityModal.hide();
    updateCartDisplay();
    checkValidateButton();
}

// Mettre à jour l'affichage du panier
function updateCartDisplay() {
    const tbody = document.getElementById('cartTableBody');
    const cartCount = document.getElementById('cartItemsCount');
    const cartTotal = document.getElementById('cartTotal');
    
    if (cart.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-4 text-muted">
                    <i class="fa fa-shopping-cart fa-3x mb-3"></i>
                    <p>Panier vide</p>
                </td>
            </tr>
        `;
        cartCount.textContent = '0 article';
        cartTotal.textContent = formatPrice(0);
        return;
    }
    
    let html = '';
    let total = 0;
    
    cart.forEach((item, index) => {
        total += item.montant;
        html += `
            <tr>
                <td>
                    ${escapeHtml(item.nom)}
                    <br>
                    <small class="text-muted">Stock: ${item.stock_max} ${item.unite}</small>
                </td>
                <td>
                    <div class="input-group input-group-sm">
                        <button class="btn btn-outline-secondary" 
                                onclick="updateQuantity(${index}, -1)">-</button>
                        <span class="mx-2">${item.quantite}</span>
                        <button class="btn btn-outline-secondary" 
                                onclick="updateQuantity(${index}, 1)">+</button>
                    </div>
                </td>
                <td>${formatPrice(item.prix_unitaire)}</td>
                <td>${formatPrice(item.montant)}</td>
                <td>
                    <button class="btn btn-sm btn-danger" onclick="removeFromCart(${index})">
                        <i class="fa fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    cartCount.textContent = cart.length + ' article(s)';
    cartTotal.textContent = formatPrice(total);
    
    // Mettre à jour le total dans le footer
    document.querySelector('.card-footer h4').textContent = formatPrice(total);
}

// Mettre à jour la quantité
function updateQuantity(index, delta) {
    const item = cart[index];
    const newQuantity = item.quantite + delta;
    
    if (newQuantity <= 0) {
        removeFromCart(index);
        return;
    }
    
    if (newQuantity > item.stock_max) {
        showNotification('Stock maximum atteint', 'warning');
        return;
    }
    
    item.quantite = newQuantity;
    item.montant = item.quantite * item.prix_unitaire;
    updateCartDisplay();
    checkValidateButton();
}

// Retirer du panier
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartDisplay();
    checkValidateButton();
}

// Calculer la monnaie à rendre
function calculateChange() {
    const total = cart.reduce((sum, item) => sum + item.montant, 0);
    const paye = parseFloat(document.getElementById('montantPaye').value) || 0;
    const monnaie = Math.max(0, paye - total);
    
    document.getElementById('monnaieRendue').textContent = formatPrice(monnaie);
    
    // Activer/désactiver le bouton de validation
    checkValidateButton();
}

// Vérifier si le bouton de validation doit être activé
function checkValidateButton() {
    const total = cart.reduce((sum, item) => sum + item.montant, 0);
    const paye = parseFloat(document.getElementById('montantPaye').value) || 0;
    const btn = document.getElementById('validateSaleBtn');
    
    btn.disabled = cart.length === 0 || paye < total;
}

// Valider la vente
async function validateSale() {
    if (cart.length === 0) {
        showNotification('Panier vide', 'warning');
        return;
    }
    
    const total = cart.reduce((sum, item) => sum + item.montant, 0);
    const paye = parseFloat(document.getElementById('montantPaye').value) || 0;
    
    if (paye < total) {
        showNotification('Montant payé insuffisant', 'warning');
        return;
    }
    
    const saleData = {
        client_nom: document.getElementById('clientNom').value.trim() || null,
        client_contact: document.getElementById('clientContact').value.trim() || null,
        items: cart.map(item => ({
            produit_id: item.produit_id,
            quantite: item.quantite,
            prix_unitaire: item.prix_unitaire,
            montant: item.montant
        })),
        montant_total: total,
        montant_paye: paye,
        monnaie_rendue: paye - total
    };
    
    try {
        showLoading();
        
        const result = await window.api.createSale(saleData);
        
        if (result.success) {
            showNotification('Vente enregistrée avec succès', 'success');
            
            // Générer la facture
            await window.api.generateInvoice(result.venteId);
            
            // Vider le panier
            cart = [];
            document.getElementById('clientNom').value = '';
            document.getElementById('clientContact').value = '';
            document.getElementById('montantPaye').value = '0';
            updateCartDisplay();
            calculateChange();
            
            // Proposer d'imprimer la facture
            if (confirm('Voulez-vous ouvrir la facture ?')) {
                window.api.openInvoice(result.venteId);
            }
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur validation vente:', error);
        showNotification('Erreur lors de la validation', 'danger');
    } finally {
        hideLoading();
    }
}

// Fonctions utilitaires
function formatPrice(price) {
    return new Intl.NumberFormat('fr-GN', {
        style: 'currency',
        currency: 'GNF',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(price);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showLoading() {
    // Ajouter un loader
    const btn = document.getElementById('validateSaleBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Traitement...';
}

function hideLoading() {
    const btn = document.getElementById('validateSaleBtn');
    btn.innerHTML = '<i class="fa fa-check-circle"></i> Valider la vente';
    checkValidateButton();
}