let originalSettings = {};

// Initialisation de la page
window.initPage = function() {
    loadSettings();
    initEventListeners();
};

// Charger les paramètres
async function loadSettings() {
    try {
        const result = await window.api.getCompanySettings();
        if (result.success) {
            originalSettings = result.data;
            displaySettings(result.data);
        } else {
            showNotification('Erreur de chargement des paramètres', 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur de communication', 'danger');
    }
}

// Afficher les paramètres
function displaySettings(settings) {
    document.getElementById('companyNom').value = settings.nom || 'FOOD XPRESS';
    document.getElementById('companyDevise').value = settings.devise || 'GNF';
    document.getElementById('companyAdresse').value = settings.adresse || '';
    document.getElementById('companyTelephone').value = settings.telephone || '';
    document.getElementById('companyEmail').value = settings.email || '';
    document.getElementById('companyMessageFacture').value = 
        settings.message_bas_facture || 'Merci de votre confiance !';
    
    // Mettre à jour l'aperçu
    updatePreview();
    
    // Afficher le logo s'il existe
    if (settings.logo) {
        displayLogo(settings.logo);
    }
}

// Mettre à jour l'aperçu
function updatePreview() {
    const companyName = document.getElementById('companyNom').value || 'FOOD XPRESS';
    const message = document.getElementById('companyMessageFacture').value || 'Merci de votre confiance !';
    
    document.getElementById('previewCompanyName').textContent = companyName;
    document.getElementById('previewMessage').textContent = message;
}

// Afficher le logo
function displayLogo(logoPath) {
    const preview = document.getElementById('logoPreview');
    const defaultIcon = document.getElementById('defaultLogoIcon');
    
    if (logoPath && logoPath !== 'null') {
        // Construire le chemin complet
        const fullPath = `../../${logoPath}`;
        preview.src = fullPath;
        preview.style.display = 'inline-block';
        defaultIcon.style.display = 'none';
    } else {
        preview.style.display = 'none';
        defaultIcon.style.display = 'inline-block';
    }
}

// Upload de logo
function uploadLogo() {
    const input = document.getElementById('logoInput');
    input.click();
    
    input.onchange = function(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        // Vérifier la taille (2 Mo max)
        if (file.size > 2 * 1024 * 1024) {
            showNotification('Le fichier est trop volumineux (max 2 Mo)', 'warning');
            return;
        }
        
        // Vérifier le type
        if (!file.type.startsWith('image/')) {
            showNotification('Veuillez sélectionner une image', 'warning');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            const base64 = e.target.result;
            displayLogoPreview(base64);
            // Stocker temporairement le base64
            window.tempLogo = base64;
        };
        reader.readAsDataURL(file);
    };
}

// Afficher l'aperçu du logo
function displayLogoPreview(base64) {
    const preview = document.getElementById('logoPreview');
    const defaultIcon = document.getElementById('defaultLogoIcon');
    
    preview.src = base64;
    preview.style.display = 'inline-block';
    defaultIcon.style.display = 'none';
}

// Supprimer le logo
function removeLogo() {
    if (confirm('Supprimer le logo ?')) {
        window.tempLogo = null;
        displayLogo(null);
    }
}

// Sauvegarder les paramètres
async function saveSettings() {
    const settings = {
        nom: document.getElementById('companyNom').value.trim() || 'FOOD XPRESS',
        devise: document.getElementById('companyDevise').value,
        adresse: document.getElementById('companyAdresse').value.trim() || null,
        telephone: document.getElementById('companyTelephone').value.trim() || null,
        email: document.getElementById('companyEmail').value.trim() || null,
        message_bas_facture: document.getElementById('companyMessageFacture').value.trim() || 
                            'Merci de votre confiance !',
        logo: window.tempLogo || originalSettings.logo
    };
    
    try {
        const saveBtn = event.target;
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Sauvegarde...';
        
        const result = await window.api.updateCompanySettings(settings);
        
        if (result.success) {
            showNotification('Paramètres enregistrés', 'success');
            originalSettings = settings;
            delete window.tempLogo;
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la sauvegarde', 'danger');
    } finally {
        const saveBtn = document.querySelector('.btn-primary');
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fa fa-save"></i> Enregistrer les modifications';
    }
}

// Réinitialiser les paramètres
function resetSettings() {
    if (confirm('Annuler toutes les modifications ?')) {
        displaySettings(originalSettings);
        delete window.tempLogo;
    }
}

// Initialiser les événements
function initEventListeners() {
    document.getElementById('companyNom').addEventListener('input', updatePreview);
    document.getElementById('companyMessageFacture').addEventListener('input', updatePreview);
}