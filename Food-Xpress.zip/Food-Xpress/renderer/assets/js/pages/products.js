let productsData = [];
let categoriesData = [];
let productModal = null;
let categoriesModal = null;

// Initialisation de la page
window.initPage = function() {
    // Initialiser les modals Bootstrap
    productModal = new bootstrap.Modal(document.getElementById('productModal'));
    categoriesModal = new bootstrap.Modal(document.getElementById('categoriesModal'));
    
    // Charger les données
    loadProducts();
    loadCategories();
    loadCategoriesSelect();
    
    // Initialiser les événements
    initEvents();
};

// Charger les produits
async function loadProducts() {
    try {
        const result = await window.api.getProducts();
        if (result.success) {
            productsData = result.data;
            displayProducts(productsData);
        } else {
            showNotification('Erreur lors du chargement des produits', 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur de communication', 'danger');
    }
}

// Afficher les produits dans le tableau
function displayProducts(products) {
    const tbody = document.getElementById('productsTableBody');
    
    if (!products || products.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center py-4">
                    <i class="fa fa-box-open fa-3x text-muted mb-3"></i>
                    <p>Aucun produit trouvé</p>
                    <button class="btn btn-primary btn-sm" onclick="showAddProductModal()">
                        <i class="fa fa-plus"></i> Ajouter un produit
                    </button>
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    products.forEach(product => {
        const stockStatus = getStockStatus(product.stock_actuel, product.seuil_alerte);
        const marge = product.prix_vente - product.prix_achat;
        const margePercent = product.prix_achat > 0 ? (marge / product.prix_achat * 100).toFixed(1) : 0;
        
        html += `
            <tr>
                <td><code>${escapeHtml(product.reference)}</code></td>
                <td>
                    <strong>${escapeHtml(product.nom)}</strong>
                </td>
                <td>${escapeHtml(product.categorie_nom || '-')}</td>
                <td>${formatPrice(product.prix_achat)}</td>
                <td>${formatPrice(product.prix_vente)}</td>
                <td>
                    <span class="fw-bold">${product.stock_actuel} ${product.unite}</span>
                    <br>
                    <small class="text-muted">Marge: ${formatPrice(marge)} (${margePercent}%)</small>
                </td>
                <td>${product.seuil_alerte} ${product.unite}</td>
                <td>
                    <span class="badge ${stockStatus.class}">${stockStatus.text}</span>
                </td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary" onclick="editProduct(${product.id})" 
                                title="Modifier">
                            <i class="fa fa-edit"></i>
                        </button>
                        <button class="btn btn-outline-danger" onclick="deleteProduct(${product.id})" 
                                title="Archiver">
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Déterminer le statut du stock
function getStockStatus(stock, seuil) {
    if (stock <= 0) {
        return { class: 'badge-danger', text: 'Rupture' };
    } else if (stock < seuil) {
        return { class: 'badge-warning', text: 'Stock bas' };
    } else {
        return { class: 'badge-success', text: 'Normal' };
    }
}

// Charger les catégories
async function loadCategories() {
    try {
        const result = await window.api.getCategories();
        if (result.success) {
            categoriesData = result.data;
            displayCategories();
        }
    } catch (error) {
        console.error('Erreur chargement catégories:', error);
    }
}

// Afficher les catégories dans le modal
function displayCategories() {
    const tbody = document.getElementById('categoriesTableBody');
    
    if (!categoriesData || categoriesData.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="3" class="text-center">Aucune catégorie</td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    categoriesData.forEach(cat => {
        html += `
            <tr>
                <td>${escapeHtml(cat.nom)}</td>
                <td>${cat.nombre_produits || 0}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary" onclick="editCategory(${cat.id}, '${escapeHtml(cat.nom)}', '${escapeHtml(cat.description || '')}')">
                            <i class="fa fa-edit"></i>
                        </button>
                        <button class="btn btn-outline-danger" onclick="deleteCategory(${cat.id})" ${cat.nombre_produits > 0 ? 'disabled' : ''}>
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Charger les catégories dans le select
async function loadCategoriesSelect() {
    try {
        const result = await window.api.getCategories();
        if (result.success) {
            const select = document.getElementById('productCategorie');
            const filterSelect = document.getElementById('filterCategory');
            
            let options = '<option value="">Sélectionner une catégorie</option>';
            let filterOptions = '<option value="">Toutes les catégories</option>';
            
            result.data.forEach(cat => {
                options += `<option value="${cat.id}">${escapeHtml(cat.nom)}</option>`;
                filterOptions += `<option value="${cat.id}">${escapeHtml(cat.nom)}</option>`;
            });
            
            select.innerHTML = options;
            filterSelect.innerHTML = filterOptions;
        }
    } catch (error) {
        console.error('Erreur chargement catégories select:', error);
    }
}

// Filtrer les produits
function filterProducts() {
    const searchTerm = document.getElementById('searchProduct').value.toLowerCase();
    const categoryId = document.getElementById('filterCategory').value;
    const stockFilter = document.getElementById('filterStock').value;
    
    let filtered = productsData.filter(product => {
        // Filtre recherche
        const matchesSearch = product.nom.toLowerCase().includes(searchTerm) ||
                             product.reference.toLowerCase().includes(searchTerm);
        
        // Filtre catégorie
        const matchesCategory = !categoryId || product.categorie_id == categoryId;
        
        // Filtre stock
        let matchesStock = true;
        if (stockFilter === 'low') {
            matchesStock = product.stock_actuel > 0 && product.stock_actuel < product.seuil_alerte;
        } else if (stockFilter === 'out') {
            matchesStock = product.stock_actuel <= 0;
        } else if (stockFilter === 'normal') {
            matchesStock = product.stock_actuel >= product.seuil_alerte;
        }
        
        return matchesSearch && matchesCategory && matchesStock;
    });
    
    displayProducts(filtered);
}

// Réinitialiser les filtres
function resetFilters() {
    document.getElementById('searchProduct').value = '';
    document.getElementById('filterCategory').value = '';
    document.getElementById('filterStock').value = '';
    displayProducts(productsData);
}

// Afficher le modal d'ajout de produit
function showAddProductModal() {
    document.getElementById('productModalTitle').textContent = 'Nouveau produit';
    document.getElementById('productForm').reset();
    document.getElementById('productId').value = '';
    document.getElementById('productReference').value = '';
    document.getElementById('productStockInitial').value = '0';
    document.getElementById('productStockInitial').disabled = false;
    updateMarge();
    productModal.show();
}

// Éditer un produit
async function editProduct(id) {
    try {
        const result = await window.api.getProduct(id);
        if (result.success) {
            const product = result.data;
            
            document.getElementById('productModalTitle').textContent = 'Modifier produit';
            document.getElementById('productId').value = product.id;
            document.getElementById('productNom').value = product.nom;
            document.getElementById('productReference').value = product.reference;
            document.getElementById('productReference').disabled = true;
            document.getElementById('productCategorie').value = product.categorie_id || '';
            document.getElementById('productUnite').value = product.unite;
            document.getElementById('productPrixAchat').value = product.prix_achat;
            document.getElementById('productPrixVente').value = product.prix_vente;
            document.getElementById('productSeuilAlerte').value = product.seuil_alerte;
            document.getElementById('productStockInitial').value = '0';
            document.getElementById('productStockInitial').disabled = true;
            
            updateMarge();
            productModal.show();
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors du chargement du produit', 'danger');
    }
}

// Sauvegarder un produit
async function saveProduct() {
    // Validation
    const nom = document.getElementById('productNom').value.trim();
    const prixAchat = parseFloat(document.getElementById('productPrixAchat').value) || 0;
    const prixVente = parseFloat(document.getElementById('productPrixVente').value) || 0;
    
    if (!nom) {
        showNotification('Le nom du produit est obligatoire', 'warning');
        return;
    }
    
    if (prixVente < prixAchat) {
        if (!confirm('Le prix de vente est inférieur au prix d\'achat. Voulez-vous continuer ?')) {
            return;
        }
    }
    
    const productData = {
        id: document.getElementById('productId').value,
        nom: nom,
        reference: document.getElementById('productReference').value.trim(),
        categorie_id: document.getElementById('productCategorie').value || null,
        unite: document.getElementById('productUnite').value,
        prix_achat: prixAchat,
        prix_vente: prixVente,
        seuil_alerte: parseFloat(document.getElementById('productSeuilAlerte').value) || 5,
        stock_initial: parseFloat(document.getElementById('productStockInitial').value) || 0
    };
    
    try {
        let result;
        if (productData.id) {
            // Mise à jour
            result = await window.api.updateProduct(productData);
        } else {
            // Création
            result = await window.api.createProduct(productData);
        }
        
        if (result.success) {
            showNotification(result.message, 'success');
            productModal.hide();
            loadProducts();
        } else {
            showNotification(result.message, result.warning ? 'warning' : 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la sauvegarde', 'danger');
    }
}

// Supprimer/Archiver un produit
async function deleteProduct(id) {
    if (!confirm('Êtes-vous sûr de vouloir archiver ce produit ?')) {
        return;
    }
    
    try {
        const result = await window.api.deleteProduct(id);
        if (result.success) {
            showNotification(result.message, 'success');
            loadProducts();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la suppression', 'danger');
    }
}

// Ajouter une catégorie
async function addCategory() {
    const nom = document.getElementById('newCategoryName').value.trim();
    if (!nom) {
        showNotification('Veuillez entrer un nom de catégorie', 'warning');
        return;
    }
    
    try {
        const result = await window.api.createCategory({ nom });
        if (result.success) {
            showNotification('Catégorie ajoutée', 'success');
            document.getElementById('newCategoryName').value = '';
            await loadCategories();
            await loadCategoriesSelect();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de l\'ajout', 'danger');
    }
}

// Supprimer une catégorie
async function deleteCategory(id) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ?')) {
        return;
    }
    
    try {
        const result = await window.api.deleteCategory(id);
        if (result.success) {
            showNotification('Catégorie supprimée', 'success');
            await loadCategories();
            await loadCategoriesSelect();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la suppression', 'danger');
    }
}

// Mettre à jour la marge
function updateMarge() {
    const prixAchat = parseFloat(document.getElementById('productPrixAchat').value) || 0;
    const prixVente = parseFloat(document.getElementById('productPrixVente').value) || 0;
    const marge = prixVente - prixAchat;
    const margePercent = prixAchat > 0 ? (marge / prixAchat * 100).toFixed(1) : 0;
    
    document.getElementById('productMarge').textContent = 
        `${formatPrice(marge)} (${margePercent}%)`;
}

// Initialiser les événements
function initEvents() {
    document.getElementById('productPrixAchat').addEventListener('input', updateMarge);
    document.getElementById('productPrixVente').addEventListener('input', updateMarge);
}

// Formater le prix
function formatPrice(price) {
    return new Intl.NumberFormat('fr-GN', {
        style: 'currency',
        currency: 'GNF',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(price);
}

// Échapper le HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}