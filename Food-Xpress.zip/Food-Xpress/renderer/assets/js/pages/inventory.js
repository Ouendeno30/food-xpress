let movementsData = [];
let productsList = [];

// Initialisation de la page
window.initPage = function() {
    loadInventoryData();
    loadProductsSelect();
    loadMovements();
};

// Charger les données d'inventaire
async function loadInventoryData() {
    try {
        const result = await window.api.getInventory();
        if (result.success) {
            updateInventorySummary(result.data);
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors du chargement de l\'inventaire', 'danger');
    }
}

// Mettre à jour le résumé
function updateInventorySummary(data) {
    let normal = 0, low = 0, out = 0, totalValue = 0;
    
    data.forEach(product => {
        totalValue += product.stock_actuel * product.prix_achat;
        
        if (product.stock_actuel <= 0) {
            out++;
        } else if (product.stock_actuel < product.seuil_alerte) {
            low++;
        } else {
            normal++;
        }
    });
    
    document.getElementById('normalStockCount').textContent = normal;
    document.getElementById('lowStockCount').textContent = low;
    document.getElementById('outStockCount').textContent = out;
    document.getElementById('totalValue').textContent = formatPrice(totalValue);
}

// Charger les mouvements
async function loadMovements() {
    try {
        const result = await window.api.getStockMovements();
        if (result.success) {
            movementsData = result.data;
            displayMovements(movementsData);
        }
    } catch (error) {
        console.error('Erreur:', error);
    }
}

// Afficher les mouvements
function displayMovements(movements) {
    const tbody = document.getElementById('movementsTableBody');
    
    if (!movements || movements.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="text-center">Aucun mouvement</td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    movements.slice(0, 20).forEach(m => {
        const typeClass = {
            'entree': 'badge-success',
            'sortie': 'badge-info',
            'correction': 'badge-warning'
        }[m.type_mouvement] || 'badge-secondary';
        
        const typeText = {
            'entree': 'Entrée',
            'sortie': 'Sortie',
            'correction': 'Correction'
        }[m.type_mouvement] || m.type_mouvement;
        
        html += `
            <tr>
                <td>${new Date(m.created_at).toLocaleString('fr-FR')}</td>
                <td>${escapeHtml(m.produit_nom)}</td>
                <td><span class="badge ${typeClass}">${typeText}</span></td>
                <td class="fw-bold">${m.quantite} ${m.unite}</td>
                <td>${m.stock_avant} ${m.unite}</td>
                <td>${m.stock_apres} ${m.unite}</td>
                <td>${escapeHtml(m.utilisateur_nom)}</td>
                <td><small>${escapeHtml(m.justification || '-')}</small></td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Charger les produits pour le select
async function loadProductsSelect() {
    try {
        const result = await window.api.getProducts();
        if (result.success) {
            productsList = result.data;
            const select = document.getElementById('adjustProduct');
            
            let options = '<option value="">Sélectionner un produit</option>';
            productsList.forEach(p => {
                options += `<option value="${p.id}">${escapeHtml(p.nom)} (Stock: ${p.stock_actuel} ${p.unite})</option>`;
            });
            
            select.innerHTML = options;
        }
    } catch (error) {
        console.error('Erreur:', error);
    }
}

// Afficher le modal d'ajustement
function showAdjustStockModal() {
    document.getElementById('adjustStockForm').reset();
    document.getElementById('currentStock').textContent = '-';
    new bootstrap.Modal(document.getElementById('adjustStockModal')).show();
}

// Mettre à jour le stock actuel quand on change de produit
document.getElementById('adjustProduct').addEventListener('change', function() {
    const productId = this.value;
    if (productId) {
        const product = productsList.find(p => p.id == productId);
        if (product) {
            document.getElementById('currentStock').textContent = 
                `${product.stock_actuel} ${product.unite}`;
        }
    } else {
        document.getElementById('currentStock').textContent = '-';
    }
});

// Sauvegarder l'ajustement
async function saveAdjustment() {
    const productId = document.getElementById('adjustProduct').value;
    const newStock = parseFloat(document.getElementById('newStock').value);
    const reason = document.getElementById('adjustmentReason').value.trim();
    
    if (!productId || isNaN(newStock) || !reason) {
        showNotification('Tous les champs sont obligatoires', 'warning');
        return;
    }
    
    const product = productsList.find(p => p.id == productId);
    if (!product) return;
    
    if (newStock === product.stock_actuel) {
        showNotification('Le nouveau stock est identique au stock actuel', 'warning');
        return;
    }
    
    const adjustmentData = {
        produit_id: productId,
        nouveau_stock: newStock,
        justification: reason
    };
    
    try {
        const result = await window.api.adjustInventory(adjustmentData);
        if (result.success) {
            showNotification('Inventaire ajusté avec succès', 'success');
            bootstrap.Modal.getInstance(document.getElementById('adjustStockModal')).hide();
            loadInventoryData();
            loadMovements();
            loadProductsSelect();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de l\'ajustement', 'danger');
    }
}

// Formater le prix
function formatPrice(price) {
    return new Intl.NumberFormat('fr-GN', {
        style: 'currency',
        currency: 'GNF',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(price);
}

// Échapper le HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}