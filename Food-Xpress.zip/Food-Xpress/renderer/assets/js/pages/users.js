let usersData = [];
let currentUserId = null;
let userModal = null;
let resetPasswordModal = null;
let userDetailsModal = null;
let selectedUserId = null;

// Initialisation de la page
window.initPage = async function() {
    userModal = new bootstrap.Modal(document.getElementById('userModal'));
    resetPasswordModal = new bootstrap.Modal(document.getElementById('resetPasswordModal'));
    userDetailsModal = new bootstrap.Modal(document.getElementById('userDetailsModal'));
    
    await loadUsers();
    await loadCurrentUser();
};

// Charger l'utilisateur courant
async function loadCurrentUser() {
    try {
        const result = await window.api.getCurrentUser();
        if (result.success) {
            currentUserId = result.user.userId;
        }
    } catch (error) {
        console.error('Erreur:', error);
    }
}

// Charger les utilisateurs
async function loadUsers() {
    try {
        const result = await window.api.getUsers();
        if (result.success) {
            usersData = result.data;
            displayUsers(usersData);
            updateStatistics(usersData);
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur de chargement', 'danger');
    }
}

// Afficher les utilisateurs
function displayUsers(users) {
    const tbody = document.getElementById('usersTableBody');
    
    if (!users || users.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center py-4">
                    <i class="fa fa-users fa-3x text-muted mb-3"></i>
                    <p>Aucun utilisateur trouvé</p>
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    users.forEach(user => {
        const isCurrentUser = user.id === currentUserId;
        const roleClass = user.role === 'admin' ? 'badge-danger' : 'badge-info';
        const roleText = user.role === 'admin' ? 'Administrateur' : 'Vendeur';
        const statusClass = user.actif ? 'badge-success' : 'badge-secondary';
        const statusText = user.actif ? 'Actif' : 'Inactif';
        const lockedClass = user.login_attempts >= 5 ? 'badge-warning' : 'badge-success';
        const lockedText = user.login_attempts >= 5 ? 'Bloqué' : 'Normal';
        
        const lastLogin = user.last_login ? 
            new Date(user.last_login).toLocaleString('fr-FR') : 'Jamais';
        
        html += `
            <tr ${isCurrentUser ? 'class="table-primary"' : ''}>
                <td>
                    <strong>${escapeHtml(user.nom_complet)}</strong>
                    ${isCurrentUser ? '<span class="badge bg-info ms-2">Vous</span>' : ''}
                </td>
                <td><code>${escapeHtml(user.username)}</code></td>
                <td><span class="badge ${roleClass}">${roleText}</span></td>
                <td><span class="badge ${statusClass}">${statusText}</span></td>
                <td>
                    <span class="badge ${lockedClass}">${lockedText}</span>
                    <small class="text-muted d-block">${user.login_attempts || 0}/5</small>
                </td>
                <td><small>${lastLogin}</small></td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-info" onclick="showUserDetails(${user.id})"
                                title="Détails">
                            <i class="fa fa-eye"></i>
                        </button>
                        <button class="btn btn-outline-primary" onclick="editUser(${user.id})"
                                title="Modifier">
                            <i class="fa fa-edit"></i>
                        </button>
                        <button class="btn btn-outline-warning" onclick="showResetPassword(${user.id})"
                                title="Réinitialiser mot de passe">
                            <i class="fa fa-key"></i>
                        </button>
                        ${user.login_attempts >= 5 ? `
                        <button class="btn btn-outline-success" onclick="unlockUser(${user.id})"
                                title="Débloquer">
                            <i class="fa fa-unlock"></i>
                        </button>
                        ` : ''}
                        <button class="btn btn-outline-danger" onclick="deleteUser(${user.id})"
                                title="Supprimer/Désactiver"
                                ${isCurrentUser ? 'disabled' : ''}>
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Mettre à jour les statistiques
function updateStatistics(users) {
    const total = users.length;
    const admins = users.filter(u => u.role === 'admin').length;
    const sellers = users.filter(u => u.role === 'vendeur').length;
    const locked = users.filter(u => u.login_attempts >= 5).length;
    
    document.getElementById('totalUsers').textContent = total;
    document.getElementById('totalAdmins').textContent = admins;
    document.getElementById('totalSellers').textContent = sellers;
    document.getElementById('totalLocked').textContent = locked;
}

// Afficher le modal d'ajout
function showAddUserModal() {
    document.getElementById('userModalTitle').textContent = 'Nouvel utilisateur';
    document.getElementById('userForm').reset();
    document.getElementById('userId').value = '';
    document.getElementById('userActif').checked = true;
    
    // Rendre le mot de passe obligatoire
    document.getElementById('userPassword').required = true;
    document.getElementById('passwordHelp').style.display = 'block';
    document.getElementById('confirmPasswordGroup').style.display = 'block';
    
    userModal.show();
}

// Éditer un utilisateur
async function editUser(id) {
    const user = usersData.find(u => u.id === id);
    if (!user) return;
    
    document.getElementById('userModalTitle').textContent = 'Modifier utilisateur';
    document.getElementById('userId').value = user.id;
    document.getElementById('userNomComplet').value = user.nom_complet;
    document.getElementById('userUsername').value = user.username;
    document.getElementById('userRole').value = user.role;
    document.getElementById('userActif').checked = user.actif === 1;
    
    // Rendre le mot de passe optionnel
    document.getElementById('userPassword').required = false;
    document.getElementById('userPassword').value = '';
    document.getElementById('passwordHelp').style.display = 'none';
    document.getElementById('confirmPasswordGroup').style.display = 'none';
    
    userModal.show();
}

// Sauvegarder un utilisateur
async function saveUser() {
    const id = document.getElementById('userId').value;
    const nomComplet = document.getElementById('userNomComplet').value.trim();
    const username = document.getElementById('userUsername').value.trim();
    const role = document.getElementById('userRole').value;
    const actif = document.getElementById('userActif').checked;
    const password = document.getElementById('userPassword').value;
    const confirmPassword = document.getElementById('userConfirmPassword').value;
    
    // Validations
    if (!nomComplet || !username) {
        showNotification('Veuillez remplir tous les champs obligatoires', 'warning');
        return;
    }
    
    // Pour un nouvel utilisateur, le mot de passe est obligatoire
    if (!id && !password) {
        showNotification('Le mot de passe est obligatoire pour un nouvel utilisateur', 'warning');
        return;
    }
    
    // Si un mot de passe est fourni, le valider
    if (password) {
        if (password.length < 8) {
            showNotification('Le mot de passe doit contenir au moins 8 caractères', 'warning');
            return;
        }
        
        if (password !== confirmPassword) {
            showNotification('Les mots de passe ne correspondent pas', 'warning');
            return;
        }
    }
    
    const userData = {
        id: id || undefined,
        nom_complet: nomComplet,
        username: username,
        role: role,
        actif: actif
    };
    
    if (password) {
        userData.password = password;
    }
    
    try {
        const saveBtn = event.target;
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Sauvegarde...';
        
        let result;
        if (id) {
            result = await window.api.updateUser(userData);
        } else {
            result = await window.api.createUser(userData);
        }
        
        if (result.success) {
            showNotification(result.message, 'success');
            userModal.hide();
            await loadUsers();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la sauvegarde', 'danger');
    } finally {
        const saveBtn = document.querySelector('#userModal .btn-primary');
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fa fa-save"></i> Enregistrer';
    }
}

// Supprimer un utilisateur
async function deleteUser(id) {
    if (id === currentUserId) {
        showNotification('Vous ne pouvez pas supprimer votre propre compte', 'warning');
        return;
    }
    
    if (!confirm('Êtes-vous sûr de vouloir supprimer/désactiver cet utilisateur ?')) {
        return;
    }
    
    try {
        const result = await window.api.deleteUser(id);
        if (result.success) {
            showNotification(result.message, 'success');
            await loadUsers();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la suppression', 'danger');
    }
}

// Afficher le modal de réinitialisation de mot de passe
function showResetPassword(id) {
    const user = usersData.find(u => u.id === id);
    if (!user) return;
    
    selectedUserId = id;
    document.getElementById('resetUserName').textContent = user.nom_complet;
    document.getElementById('resetNewPassword').value = '';
    document.getElementById('resetConfirmPassword').value = '';
    
    resetPasswordModal.show();
}

// Confirmer la réinitialisation du mot de passe
async function confirmResetPassword() {
    const newPassword = document.getElementById('resetNewPassword').value;
    const confirmPassword = document.getElementById('resetConfirmPassword').value;
    
    if (!newPassword || newPassword.length < 8) {
        showNotification('Le mot de passe doit contenir au moins 8 caractères', 'warning');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        showNotification('Les mots de passe ne correspondent pas', 'warning');
        return;
    }
    
    try {
        const result = await window.api.resetUserPassword(selectedUserId, newPassword);
        
        if (result.success) {
            showNotification(result.message, 'success');
            resetPasswordModal.hide();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la réinitialisation', 'danger');
    }
}

// Débloquer un utilisateur
async function unlockUser(id) {
    if (!confirm('Débloquer ce compte ?')) {
        return;
    }
    
    try {
        const result = await window.api.unlockUser(id);
        if (result.success) {
            showNotification(result.message, 'success');
            await loadUsers();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors du déblocage', 'danger');
    }
}

// Afficher les détails d'un utilisateur
function showUserDetails(id) {
    const user = usersData.find(u => u.id === id);
    if (!user) return;
    
    document.getElementById('detailNomComplet').textContent = user.nom_complet;
    document.getElementById('detailUsername').textContent = user.username;
    document.getElementById('detailRole').textContent = 
        user.role === 'admin' ? 'Administrateur' : 'Vendeur';
    document.getElementById('detailRole').className = 
        `badge ${user.role === 'admin' ? 'bg-danger' : 'bg-info'}`;
    
    const status = user.actif ? 'Actif' : 'Inactif';
    const statusClass = user.actif ? 'bg-success' : 'bg-secondary';
    document.getElementById('detailStatut').innerHTML = 
        `<span class="badge ${statusClass}">${status}</span>`;
    
    document.getElementById('detailCreatedAt').textContent = 
        user.created_at ? new Date(user.created_at).toLocaleString('fr-FR') : 'Inconnue';
    document.getElementById('detailLastLogin').textContent = 
        user.last_login ? new Date(user.last_login).toLocaleString('fr-FR') : 'Jamais';
    document.getElementById('detailLoginAttempts').textContent = 
        `${user.login_attempts || 0} / 5`;
    
    userDetailsModal.show();
}

// Fonction utilitaire pour afficher/masquer le mot de passe
window.togglePassword = function(fieldId) {
    const field = document.getElementById(fieldId);
    const type = field.type === 'password' ? 'text' : 'password';
    field.type = type;
    
    const icon = event.currentTarget.querySelector('i');
    if (type === 'text') {
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
};

// Échapper le HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}