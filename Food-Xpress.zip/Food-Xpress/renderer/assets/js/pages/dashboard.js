// Variables globales
let salesChart = null;
let categoryChart = null;
let currentPeriod = 7;

// Initialisation
window.initPage = function() {
    loadDashboardData();
    initEventListeners();
};

// Charger les données
async function loadDashboardData() {
    try {
        showLoading();
        
        const stats = await getDashboardStats();
        updateKPIs(stats);
        
        await updateCharts();
        
        const topProducts = await getTopProducts();
        updateTopProducts(topProducts);
        
        const alertProducts = await getAlertProducts();
        updateAlertProducts(alertProducts);
        
    } catch (error) {
        console.error('Erreur chargement dashboard:', error);
        showNotification('Erreur de chargement des données', 'danger');
    } finally {
        hideLoading();
    }
}

// Récupérer les statistiques
async function getDashboardStats() {
    // Simuler pour le moment
    return {
        revenue: 1250000,
        revenueTrend: 15,
        salesCount: 24,
        productsSold: 156,
        lowStockCount: 8,
        outOfStockCount: 3
    };
}

// Mettre à jour les KPI
function updateKPIs(stats) {
    document.getElementById('kpiRevenue').textContent = formatPrice(stats.revenue);
    document.getElementById('kpiSalesCount').textContent = stats.salesCount;
    document.getElementById('kpiLowStock').textContent = stats.lowStockCount;
    document.getElementById('kpiOutOfStock').textContent = stats.outOfStockCount;
    
    document.getElementById('salesCountDetail').textContent = stats.productsSold + ' produits';
    
    const trend = document.getElementById('revenueTrend');
    trend.textContent = (stats.revenueTrend > 0 ? '+' : '') + stats.revenueTrend + '%';
    trend.className = stats.revenueTrend > 0 ? 'text-success' : 'text-danger';
}

// Mettre à jour les graphiques
async function updateCharts() {
    const salesData = await getSalesData();
    updateSalesChart(salesData);
    
    const categoryData = await getCategoryData();
    updateCategoryChart(categoryData);
}

// Données des ventes
async function getSalesData() {
    return {
        labels: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'],
        values: [150000, 200000, 175000, 220000, 300000, 280000, 250000]
    };
}

// Mettre à jour graphique des ventes
function updateSalesChart(data) {
    const ctx = document.getElementById('salesChart').getContext('2d');
    
    if (salesChart) {
        salesChart.destroy();
    }
    
    salesChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Chiffre d\'affaires',
                data: data.values,
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#667eea',
                pointBorderColor: 'white',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (context) => formatPrice(context.raw)
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { display: true, color: '#f0f0f0' },
                    ticks: {
                        callback: (value) => formatPrice(value, true)
                    }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
}

// Données des catégories
async function getCategoryData() {
    return {
        labels: ['Boissons', 'Céréales', 'Conserves', 'Fruits', 'Légumes'],
        values: [35, 25, 20, 12, 8],
        colors: ['#667eea', '#48bb78', '#f56565', '#ed8936', '#9f7aea']
    };
}

// Mettre à jour graphique des catégories
function updateCategoryChart(data) {
    const ctx = document.getElementById('categoryChart').getContext('2d');
    
    if (categoryChart) {
        categoryChart.destroy();
    }
    
    categoryChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.labels,
            datasets: [{
                data: data.values,
                backgroundColor: data.colors || [
                    '#667eea', '#48bb78', '#f56565', '#ed8936', '#9f7aea', '#4299e1'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            },
            cutout: '70%'
        }
    });
}

// Top produits
async function getTopProducts() {
    return [
        { nom: 'Riz 25kg', quantite: 45, unite: 'sac', ca: 450000 },
        { nom: 'Huile 5L', quantite: 38, unite: 'bouteille', ca: 342000 },
        { nom: 'Sucre 1kg', quantite: 62, unite: 'kg', ca: 310000 },
        { nom: 'Tomate', quantite: 85, unite: 'kg', ca: 255000 },
        { nom: 'Oignon', quantite: 70, unite: 'kg', ca: 210000 }
    ];
}

function updateTopProducts(products) {
    const tbody = document.getElementById('topProductsTable');
    
    if (!products || products.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="3" class="text-center py-4 text-muted">
                    Aucune donnée disponible
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    products.forEach(p => {
        html += `
            <tr>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="product-icon bg-primary bg-opacity-10 rounded p-2 me-2">
                            <i class="fa fa-cube text-primary"></i>
                        </div>
                        <div>
                            <strong>${escapeHtml(p.nom)}</strong>
                            <br>
                            <small class="text-muted">${p.quantite} ${p.unite}</small>
                        </div>
                    </div>
                </td>
                <td class="text-end fw-bold">${p.quantite}</td>
                <td class="text-end text-primary fw-bold">${formatPrice(p.ca)}</td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Produits en alerte
async function getAlertProducts() {
    return [
        { nom: 'Lait', stock: 3, seuil: 10, unite: 'bouteille', statut: 'Alerte' },
        { nom: 'Pain', stock: 0, seuil: 5, unite: 'piece', statut: 'Rupture' },
        { nom: 'Beurre', stock: 2, seuil: 8, unite: 'piece', statut: 'Alerte' }
    ];
}

function updateAlertProducts(products) {
    const tbody = document.getElementById('alertProductsTable');
    
    if (!products || products.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center py-4 text-success">
                    <i class="fa fa-check-circle fa-2x mb-2"></i>
                    <br>Aucun produit en alerte
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    products.forEach(p => {
        const statusClass = p.stock === 0 ? 'bg-danger' : 'bg-warning';
        const statusText = p.stock === 0 ? 'Rupture' : 'Stock bas';
        
        html += `
            <tr>
                <td>
                    <strong>${escapeHtml(p.nom)}</strong>
                </td>
                <td class="text-end fw-bold ${p.stock === 0 ? 'text-danger' : ''}">
                    ${p.stock} ${p.unite}
                </td>
                <td class="text-end">${p.seuil} ${p.unite}</td>
                <td class="text-center">
                    <span class="badge ${statusClass} text-white px-3 py-2">${statusText}</span>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Changer période
function changePeriod(period) {
    currentPeriod = period;
    
    // Mettre à jour les boutons
    document.querySelectorAll('[onclick^="changePeriod"]').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Recharger les données
    updateCharts();
}

// Utilitaires
function formatPrice(price, compact = false) {
    if (compact) {
        if (price >= 1000000) return (price / 1000000).toFixed(1) + 'M';
        if (price >= 1000) return (price / 1000).toFixed(0) + 'k';
    }
    
    return new Intl.NumberFormat('fr-GN', {
        style: 'currency',
        currency: 'GNF',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(price);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showLoading() {
    // Déjà géré par le loader
}

function hideLoading() {
    // Déjà géré par le loader
}

function showNotification(message, type) {
    // Utiliser la fonction du layout
    if (window.showNotification) {
        window.showNotification(message, type);
    }
}

// Rendre les fonctions disponibles
window.changePeriod = changePeriod;