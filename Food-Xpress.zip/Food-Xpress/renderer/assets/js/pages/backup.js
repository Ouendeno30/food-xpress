let backupModal = null;
let restoreModal = null;
let backupsList = [];

// Initialisation de la page
window.initPage = function() {
    backupModal = new bootstrap.Modal(document.getElementById('backupModal'));
    restoreModal = new bootstrap.Modal(document.getElementById('restoreModal'));
    
    loadBackupInfo();
    
    // Écouter les notifications de sauvegarde
    window.api.on('backup-notification', (data) => {
        showNotification(data.message, data.type);
        loadBackupInfo(); // Rafraîchir après une sauvegarde
    });
};

// Charger les informations de sauvegarde
async function loadBackupInfo() {
    try {
        const result = await window.api.getBackupInfo();
        if (result.success) {
            backupsList = result.backupsList || [];
            updateLastBackupInfo(result.lastBackup);
            updateBackupsList(backupsList);
            updateBackupReminder(result.needsBackup);
            document.getElementById('backupsCount').textContent = 
                `${backupsList.length} sauvegarde(s)`;
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur de chargement', 'danger');
    }
}

// Mettre à jour les informations de dernière sauvegarde
function updateLastBackupInfo(lastBackup) {
    const container = document.getElementById('lastBackupInfo');
    
    if (!lastBackup || !lastBackup.exists) {
        container.innerHTML = `
            <div class="text-center py-4">
                <i class="fa fa-exclamation-circle fa-3x text-warning mb-3"></i>
                <h6>Aucune sauvegarde trouvée</h6>
                <p class="text-muted">Effectuez votre première sauvegarde</p>
                <button class="btn btn-primary btn-sm" onclick="showBackupModal()">
                    <i class="fa fa-database"></i> Sauvegarder maintenant
                </button>
            </div>
        `;
        return;
    }
    
    const date = new Date(lastBackup.date).toLocaleString('fr-FR');
    const size = formatFileSize(lastBackup.size);
    const daysAgo = getDaysAgo(lastBackup.date);
    
    container.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="flex-shrink-0">
                <i class="fa fa-check-circle fa-3x text-success"></i>
            </div>
            <div class="flex-grow-1 ms-3">
                <h6 class="mb-1">${lastBackup.name}</h6>
                <p class="mb-1 text-muted">
                    <i class="fa fa-calendar"></i> ${date}<br>
                    <i class="fa fa-hdd-o"></i> ${size}<br>
                    <i class="fa fa-clock-o"></i> Il y a ${daysAgo}
                </p>
            </div>
        </div>
    `;
}

// Mettre à jour la liste des sauvegardes
function updateBackupsList(backups) {
    const tbody = document.getElementById('backupsTableBody');
    
    if (!backups || backups.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-4">
                    <i class="fa fa-database fa-3x text-muted mb-3"></i>
                    <p>Aucune sauvegarde disponible</p>
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    backups.forEach(backup => {
        const date = new Date(backup.date).toLocaleString('fr-FR');
        const size = formatFileSize(backup.size);
        
        // Compter le nombre total d'enregistrements dans les métadonnées
        let totalRecords = 0;
        if (backup.metadata && backup.metadata.tables) {
            totalRecords = Object.values(backup.metadata.tables).reduce((a, b) => a + b, 0);
        }
        
        html += `
            <tr>
                <td>
                    <code>${backup.name}</code>
                </td>
                <td>${date}</td>
                <td>${size}</td>
                <td>
                    ${totalRecords > 0 ? 
                        `<span class="badge bg-info">${totalRecords} enregistrements</span>` : 
                        '<span class="badge bg-secondary">Inconnu</span>'}
                </td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-info" onclick="showBackupDetails('${backup.path}')"
                                title="Détails">
                            <i class="fa fa-info-circle"></i>
                        </button>
                        <button class="btn btn-outline-success" onclick="restoreBackup('${backup.path}')"
                                title="Restaurer">
                            <i class="fa fa-undo"></i>
                        </button>
                        <button class="btn btn-outline-danger" onclick="deleteBackup('${backup.path}')"
                                title="Supprimer">
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
}

// Mettre à jour le rappel de sauvegarde
function updateBackupReminder(needsBackup) {
    const reminder = document.getElementById('backupReminder');
    if (needsBackup) {
        reminder.style.display = 'block';
    } else {
        reminder.style.display = 'none';
    }
}

// Afficher le modal de sauvegarde
function showBackupModal() {
    backupModal.show();
}

// Sauvegarde vers le dossier par défaut
async function backupToDefault() {
    await performBackup(null);
}

// Sauvegarde vers un emplacement personnalisé
async function backupToCustom() {
    try {
        // Demander un dossier à l'utilisateur via Electron dialog
        const result = await window.api.selectFolder();
        if (result && result.path) {
            await performBackup(result.path);
        }
    } catch (error) {
        console.error('Erreur sélection dossier:', error);
        showNotification('Erreur lors de la sélection du dossier', 'danger');
    }
}

// Sauvegarde rapide (alias pour backupToDefault)
async function quickBackup() {
    await backupToDefault();
}

// Sauvegarde sur USB (sélection de dossier)
async function backupToUSB() {
    await backupToCustom();
}

// Effectuer la sauvegarde
async function performBackup(destinationPath) {
    try {
        const saveBtn = event?.target;
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Sauvegarde...';
        }
        
        const result = await window.api.backupDatabase(destinationPath);
        
        if (result.success) {
            showNotification(result.message, 'success');
            backupModal.hide();
            await loadBackupInfo();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la sauvegarde', 'danger');
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<i class="fa fa-database"></i> Sauvegarder maintenant';
        }
    }
}

// Ouvrir le dossier des sauvegardes
async function openBackupFolder() {
    try {
        await window.api.openBackupFolder();
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de l\'ouverture du dossier', 'danger');
    }
}

// Afficher le modal de restauration
async function showRestoreModal() {
    // Charger la liste des sauvegardes dans le select
    const select = document.getElementById('restoreSelect');
    
    if (backupsList.length === 0) {
        select.innerHTML = '<option value="">Aucune sauvegarde disponible</option>';
    } else {
        let options = '<option value="">Sélectionnez une sauvegarde...</option>';
        backupsList.forEach(backup => {
            const date = new Date(backup.date).toLocaleString('fr-FR');
            options += `<option value="${backup.path}">${backup.name} (${date})</option>`;
        });
        select.innerHTML = options;
    }
    
    document.getElementById('restoreFilePath').value = '';
    restoreModal.show();
}

// Parcourir pour choisir un fichier de sauvegarde
async function browseBackupFile() {
    try {
        const result = await window.api.selectBackupFile();
        if (result && result.path) {
            document.getElementById('restoreFilePath').value = result.path;
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la sélection du fichier', 'danger');
    }
}

// Confirmer la restauration
async function confirmRestore() {
    let backupPath = document.getElementById('restoreSelect').value;
    
    if (!backupPath) {
        backupPath = document.getElementById('restoreFilePath').value;
    }
    
    if (!backupPath) {
        showNotification('Veuillez sélectionner une sauvegarde', 'warning');
        return;
    }
    
    if (!confirm('Êtes-vous absolument sûr de vouloir restaurer cette sauvegarde ? Toutes les données actuelles seront perdues.')) {
        return;
    }
    
    try {
        const restoreBtn = document.querySelector('#restoreModal .btn-warning');
        restoreBtn.disabled = true;
        restoreBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Restauration...';
        
        const result = await window.api.restoreDatabase(backupPath);
        
        if (result.success) {
            showNotification('Restauration réussie. Redémarrage...', 'success');
            setTimeout(() => {
                window.location.reload();
            }, 2000);
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la restauration', 'danger');
    } finally {
        const restoreBtn = document.querySelector('#restoreModal .btn-warning');
        restoreBtn.disabled = false;
        restoreBtn.innerHTML = '<i class="fa fa-undo"></i> Restaurer';
    }
}

// Restaurer une sauvegarde directement depuis la liste
async function restoreBackup(path) {
    document.getElementById('restoreFilePath').value = path;
    restoreModal.show();
}

// Supprimer une sauvegarde
async function deleteBackup(path) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette sauvegarde ?')) {
        return;
    }
    
    try {
        const result = await window.api.deleteBackup(path);
        if (result.success) {
            showNotification('Sauvegarde supprimée', 'success');
            await loadBackupInfo();
        } else {
            showNotification(result.message, 'danger');
        }
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors de la suppression', 'danger');
    }
}

// Afficher les détails d'une sauvegarde
async function showBackupDetails(path) {
    const backup = backupsList.find(b => b.path === path);
    if (!backup) return;
    
    let details = `Détails de la sauvegarde\n`;
    details += `Fichier: ${backup.name}\n`;
    details += `Date: ${new Date(backup.date).toLocaleString('fr-FR')}\n`;
    details += `Taille: ${formatFileSize(backup.size)}\n\n`;
    
    if (backup.metadata) {
        details += `Version: ${backup.metadata.version || 'Inconnue'}\n`;
        details += `Date de création: ${new Date(backup.metadata.date).toLocaleString('fr-FR')}\n\n`;
        
        if (backup.metadata.tables) {
            details += `Contenu des tables:\n`;
            for (const [table, count] of Object.entries(backup.metadata.tables)) {
                details += `  - ${table}: ${count} enregistrement(s)\n`;
            }
        }
    }
    
    alert(details);
}

// Rafraîchir les informations
function refreshBackupInfo() {
    loadBackupInfo();
}

// Fonctions utilitaires
function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function getDaysAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'aujourd\'hui';
    if (diffDays === 1) return 'hier';
    return diffDays + ' jours';
}