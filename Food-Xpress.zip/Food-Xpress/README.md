# FOOD XPRESS - Application de Gestion de Stock et Ventes

## 📋 Description
Application desktop professionnelle pour la gestion opérationnelle du commerce de distribution alimentaire FOOD XPRESS à Mamou, République de Guinée.

## 🚀 Fonctionnalités
- **Authentification** : Connexion sécurisée avec rôles (Admin/Vendeur)
- **Gestion des produits** : Catalogue complet avec catégories
- **Gestion des stocks** : Suivi en temps réel avec alertes
- **Gestion des achats** : Enregistrement des entrées fournisseurs
- **Gestion des ventes** : Interface caisse rapide
- **Facturation PDF** : Génération automatique de factures professionnelles
- **Tableau de bord** : KPIs et graphiques analytiques
- **Sauvegarde/Restauration** : Protection des données
- **Système de licence** : Protection du logiciel

## 🛠️ Technologies utilisées
- **Framework** : Electron.js
- **Backend** : Node.js
- **Base de données** : SQLite (better-sqlite3)
- **Interface** : HTML5, CSS3, JavaScript
- **Graphiques** : Chart.js
- **PDF** : PDFKit
- **Build** : electron-builder

## 📦 Installation

### Prérequis
- Node.js 20+
- npm 10+
- Windows 7/10/11 (64 bits)

### Développement
```bash
# Cloner le projet
git clone https://github.com/ouendeno/foodxpress.git

# Installer les dépendances
npm install

# Lancer en mode développement
npm start

# Vérifier le projet
npm test

# Build pour production
npm run build