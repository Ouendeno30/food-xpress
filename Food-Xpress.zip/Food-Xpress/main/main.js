const { app, BrowserWindow, ipcMain, Menu } = require('electron');
const path = require('path');
const { initDatabase } = require('./database/database');
const { checkLicence } = require('./services/licenceManager');
const { registerHandlers } = require('./handlers');

let mainWindow;

// Garder une référence globale pour éviter le garbage collection
if (process.defaultApp) {
  if (process.argv.length >= 2) {
    app.setAsDefaultProtocolClient('foodxpress', process.execPath, [path.resolve(process.argv[1])]);
  }
} else {
  app.setAsDefaultProtocolClient('foodxpress');
}

function createWindow() {
  // Créer la fenêtre principale
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 768,
    minWidth: 1024,
    minHeight: 600,
    icon: path.join(__dirname, '../resources/icon.ico'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    show: false,
    frame: true,
    title: 'FOOD XPRESS'
  });

  // Maximiser la fenêtre
  mainWindow.maximize();

  // Charger la page d'index
  mainWindow.loadFile(path.join(__dirname, '../renderer/pages/index.html'));

  // Afficher la fenêtre quand elle est prête
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Gérer la fermeture
  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Menu personnalisé (simplifié)
  const menu = Menu.buildFromTemplate([]);
  Menu.setApplicationMenu(menu);
}

// Initialisation de l'application
app.whenReady().then(async () => {
  try {
    // Initialiser la base de données
    await initDatabase();
    console.log('✅ Base de données initialisée');

    // Enregistrer tous les handlers IPC
    registerHandlers(ipcMain, mainWindow);

    // Vérifier si une licence est activée
    const licenceValid = await checkLicence();
    
    // Créer la fenêtre
    createWindow();

    console.log('✅ Application FOOD XPRESS démarrée');
  } catch (error) {
    console.error('❌ Erreur au démarrage:', error);
    app.quit();
  }
});

// Quitter l'application quand toutes les fenêtres sont fermées
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Gestion des erreurs non capturées
process.on('uncaughtException', (error) => {
  console.error('❌ Exception non capturée:', error);
});

process.on('unhandledRejection', (error) => {
  console.error('❌ Rejection non gérée:', error);
});