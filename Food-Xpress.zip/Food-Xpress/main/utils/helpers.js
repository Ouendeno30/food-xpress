const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const { APP_NAME } = require('./constants');

// Hachage de mot de passe
function hashPassword(password) {
  const salt = bcrypt.genSaltSync(10);
  return bcrypt.hashSync(password, salt);
}

// Comparaison de mot de passe
function comparePassword(password, hash) {
  return bcrypt.compareSync(password, hash);
}

// Générer un numéro de facture unique
function generateInvoiceNumber(db) {
  const lastInvoice = db.prepare(`
    SELECT numero_facture FROM ventes 
    WHERE numero_facture LIKE 'FACT-${APP_NAME.replace(' ', '')}-%'
    ORDER BY id DESC LIMIT 1
  `).get();

  let nextNumber = 1;
  if (lastInvoice) {
    const parts = lastInvoice.numero_facture.split('-');
    nextNumber = parseInt(parts[parts.length - 1]) + 1;
  }

  return `FACT-${APP_NAME.replace(' ', '')}-${String(nextNumber).padStart(4, '0')}`;
}

// Générer un numéro d'achat unique
function generatePurchaseNumber(db) {
  const lastPurchase = db.prepare(`
    SELECT numero_achat FROM achats 
    ORDER BY id DESC LIMIT 1
  `).get();

  let nextNumber = 1;
  if (lastPurchase) {
    const parts = lastPurchase.numero_achat.split('-');
    nextNumber = parseInt(parts[parts.length - 1]) + 1;
  }

  return `ACHAT-${String(nextNumber).padStart(4, '0')}`;
}

// Formater le prix en GNF
function formatPrice(price) {
  return new Intl.NumberFormat('fr-GN', {
    style: 'currency',
    currency: 'GNF',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(price);
}

// Formater la date
function formatDate(date, includeTime = false) {
  const d = new Date(date);
  if (includeTime) {
    return d.toLocaleDateString('fr-GN') + ' ' + d.toLocaleTimeString('fr-GN');
  }
  return d.toLocaleDateString('fr-GN');
}

// Créer un dossier s'il n'existe pas
function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
  return dirPath;
}

// Journaliser les mouvements de stock
function logStockMovement(db, data) {
  const { produit_id, type_mouvement, quantite, stock_avant, stock_apres, reference_id, utilisateur_id, justification = '' } = data;
  
  const stmt = db.prepare(`
    INSERT INTO mouvements_stock 
    (produit_id, type_mouvement, quantite, stock_avant, stock_apres, reference_id, utilisateur_id, justification)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run(produit_id, type_mouvement, quantite, stock_avant, stock_apres, reference_id, utilisateur_id, justification);
}

// Valider une adresse email
function isValidEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

// Valider un numéro de téléphone guinéen (simple validation)
function isValidGuineanPhone(phone) {
  const re = /^(00224|\+224)?[0-9]{9}$/;
  return re.test(phone.replace(/\s/g, ''));
}

// Tronquer un texte
function truncateText(text, maxLength = 50) {
  if (text.length <= maxLength) return text;
  return text.substr(0, maxLength) + '...';
}

module.exports = {
  hashPassword,
  comparePassword,
  generateInvoiceNumber,
  generatePurchaseNumber,
  formatPrice,
  formatDate,
  ensureDir,
  logStockMovement,
  isValidEmail,
  isValidGuineanPhone,
  truncateText
};