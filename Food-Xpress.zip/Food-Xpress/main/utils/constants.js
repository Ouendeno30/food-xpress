module.exports = {
  APP_NAME: 'FOOD XPRESS',
  APP_VERSION: '2.0.0',
  
  // Rôles utilisateur
  ROLES: {
    ADMIN: 'admin',
    VENDEUR: 'vendeur'
  },
  
  // Types de mouvements de stock
  STOCK_MOVEMENT_TYPES: {
    ENTRÉE: 'entree',
    SORTIE: 'sortie',
    CORRECTION: 'correction'
  },
  
  // Seuils et limites
  MAX_LOGIN_ATTEMPTS: 5,
  MIN_PASSWORD_LENGTH: 8,
  BACKUP_REMINDER_DAYS: 7,
  
  // Formatage
  DATE_FORMAT: 'dd/MM/yyyy',
  DATETIME_FORMAT: 'dd/MM/yyyy HH:mm:ss',
  CURRENCY: 'GNF',
  
  // Chemins
  INVOICES_DIR: 'invoices',
  BACKUPS_DIR: 'backups',
  
  // Messages d'erreur standards
  ERRORS: {
    UNAUTHORIZED: 'Vous n\'êtes pas autorisé à effectuer cette action',
    INVALID_CREDENTIALS: 'Identifiant ou mot de passe incorrect',
    ACCOUNT_LOCKED: 'Compte bloqué après 5 tentatives. Contactez l\'administrateur',
    PRODUCT_NOT_FOUND: 'Produit non trouvé',
    INSUFFICIENT_STOCK: 'Stock insuffisant pour ce produit',
    INVOICE_NUMBER_GENERATION: 'Erreur lors de la génération du numéro de facture',
    DATABASE_ERROR: 'Erreur base de données',
    LICENCE_INVALID: 'Licence invalide ou expirée',
    LICENCE_ACTIVATION_REQUIRED: 'Veuillez activer votre licence'
  }
};