const { contextBridge, ipcRenderer } = require('electron');

// Exposer des APIs sécurisées au processus renderer
contextBridge.exposeInMainWorld('api', {
  // Authentification
  login: (credentials) => ipcRenderer.invoke('auth:login', credentials),
  logout: () => ipcRenderer.invoke('auth:logout'),
  checkAuth: () => ipcRenderer.invoke('auth:check'),
  createFirstAdmin: (userData) => ipcRenderer.invoke('auth:create-first-admin', userData),
  
  // Utilisateurs
  getUsers: () => ipcRenderer.invoke('users:get-all'),
  createUser: (userData) => ipcRenderer.invoke('users:create', userData),
  updateUser: (userData) => ipcRenderer.invoke('users:update', userData),
  deleteUser: (userId) => ipcRenderer.invoke('users:delete', userId),
  
  // Produits
  getProducts: () => ipcRenderer.invoke('products:get-all'),
  getProduct: (id) => ipcRenderer.invoke('products:get', id),
  createProduct: (productData) => ipcRenderer.invoke('products:create', productData),
  updateProduct: (productData) => ipcRenderer.invoke('products:update', productData),
  deleteProduct: (productId) => ipcRenderer.invoke('products:delete', productId),
  getProductsByCategory: (categoryId) => ipcRenderer.invoke('products:by-category', categoryId),
  
  // Catégories
  getCategories: () => ipcRenderer.invoke('categories:get-all'),
  createCategory: (categoryData) => ipcRenderer.invoke('categories:create', categoryData),
  updateCategory: (categoryData) => ipcRenderer.invoke('categories:update', categoryData),
  deleteCategory: (categoryId) => ipcRenderer.invoke('categories:delete', categoryId),
  
  // Ventes
  createSale: (saleData) => ipcRenderer.invoke('sales:create', saleData),
  getSales: (filters) => ipcRenderer.invoke('sales:get-all', filters),
  getSale: (id) => ipcRenderer.invoke('sales:get', id),
  getSalesByDate: (date) => ipcRenderer.invoke('sales:by-date', date),
  
  // Achats
  createPurchase: (purchaseData) => ipcRenderer.invoke('purchases:create', purchaseData),
  getPurchases: (filters) => ipcRenderer.invoke('purchases:get-all', filters),
  
  // Stock
  getInventory: () => ipcRenderer.invoke('stock:get-inventory'),
  getLowStock: () => ipcRenderer.invoke('stock:get-low-stock'),
  getStockMovements: (productId) => ipcRenderer.invoke('stock:movements', productId),
  adjustInventory: (adjustmentData) => ipcRenderer.invoke('stock:adjust', adjustmentData),
  
  // Statistiques / Dashboard
  getDashboardStats: () => ipcRenderer.invoke('dashboard:get-stats'),
  getTopProducts: (period) => ipcRenderer.invoke('dashboard:top-products', period),
  
  // Factures PDF
  generateInvoice: (saleId) => ipcRenderer.invoke('invoice:generate', saleId),
  getInvoicePath: (saleId) => ipcRenderer.invoke('invoice:get-path', saleId),
  
  // Sauvegarde
  backupDatabase: (backupPath) => ipcRenderer.invoke('backup:create', backupPath),
  restoreDatabase: (backupFilePath) => ipcRenderer.invoke('backup:restore', backupFilePath),
  getBackupInfo: () => ipcRenderer.invoke('backup:get-info'),
  
  // Paramètres entreprise
  getCompanySettings: () => ipcRenderer.invoke('settings:get-company'),
  updateCompanySettings: (settings) => ipcRenderer.invoke('settings:update-company', settings),
  
  // Licence
  activateLicence: (licenceKey) => ipcRenderer.invoke('licence:activate', licenceKey),
  checkLicence: () => ipcRenderer.invoke('licence:check'),
  
  // Navigation et utils
  navigate: (page) => ipcRenderer.send('navigate', page),
  getCurrentUser: () => ipcRenderer.invoke('auth:get-current-user'),
  on: (channel, callback) => {
    const validChannels = ['backup-notification'];
    if (validChannels.includes(channel)) {
      ipcRenderer.on(channel, (event, ...args) => callback(...args));
    }
  }
});