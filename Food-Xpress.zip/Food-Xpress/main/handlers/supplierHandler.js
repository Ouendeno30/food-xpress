const { getDb } = require('../database/database');

function register(ipcMain) {
  
  // Récupérer tous les fournisseurs
  ipcMain.handle('suppliers:get-all', async () => {
    const db = getDb();
    
    try {
      const fournisseurs = db.prepare(`
        SELECT f.*, COUNT(a.id) as nombre_achats,
               SUM(a.montant_total) as total_achats
        FROM fournisseurs f
        LEFT JOIN achats a ON f.id = a.fournisseur_id
        GROUP BY f.id
        ORDER BY f.nom ASC
      `).all();
      
      return { success: true, data: fournisseurs };
    } catch (error) {
      console.error('Erreur suppliers:get-all:', error);
      return { success: false, message: 'Erreur lors de la récupération des fournisseurs' };
    }
  });
  
  // Créer un fournisseur
  ipcMain.handle('suppliers:create', async (event, supplierData) => {
    const db = getDb();
    
    try {
      const result = db.prepare(`
        INSERT INTO fournisseurs (nom, telephone, adresse)
        VALUES (?, ?, ?)
      `).run(
        supplierData.nom,
        supplierData.telephone || null,
        supplierData.adresse || null
      );
      
      return { 
        success: true, 
        message: 'Fournisseur créé avec succès',
        id: result.lastInsertRowid
      };
    } catch (error) {
      console.error('Erreur suppliers:create:', error);
      return { success: false, message: 'Erreur lors de la création du fournisseur' };
    }
  });
  
  // Mettre à jour un fournisseur
  ipcMain.handle('suppliers:update', async (event, supplierData) => {
    const db = getDb();
    
    try {
      db.prepare(`
        UPDATE fournisseurs SET
          nom = ?,
          telephone = ?,
          adresse = ?
        WHERE id = ?
      `).run(
        supplierData.nom,
        supplierData.telephone || null,
        supplierData.adresse || null,
        supplierData.id
      );
      
      return { success: true, message: 'Fournisseur mis à jour avec succès' };
    } catch (error) {
      console.error('Erreur suppliers:update:', error);
      return { success: false, message: 'Erreur lors de la mise à jour du fournisseur' };
    }
  });
  
  // Supprimer un fournisseur
  ipcMain.handle('suppliers:delete', async (event, supplierId) => {
    const db = getDb();
    
    try {
      // Vérifier si le fournisseur a des achats
      const achats = db.prepare('SELECT COUNT(*) as count FROM achats WHERE fournisseur_id = ?').get(supplierId);
      
      if (achats.count > 0) {
        return { 
          success: false, 
          message: 'Impossible de supprimer : ce fournisseur a des achats enregistrés'
        };
      }
      
      db.prepare('DELETE FROM fournisseurs WHERE id = ?').run(supplierId);
      
      return { success: true, message: 'Fournisseur supprimé avec succès' };
    } catch (error) {
      console.error('Erreur suppliers:delete:', error);
      return { success: false, message: 'Erreur lors de la suppression du fournisseur' };
    }
  });
  
  console.log('  → Handler fournisseurs enregistré');
}

module.exports = { register };