const backupService = require('../services/backupService');
const { BACKUP_REMINDER_DAYS } = require('../utils/constants');
const { shell } = require('electron');
const path = require('path');

function register(ipcMain, mainWindow) {
  
  // Créer une sauvegarde
  ipcMain.handle('backup:create', async (event, backupPath = null) => {
    try {
      const result = await backupService.createBackup(backupPath);
      
      // Si la sauvegarde a réussi, notifier toutes les fenêtres
      if (result.success && mainWindow) {
        mainWindow.webContents.send('backup-notification', {
          type: 'success',
          message: result.message
        });
      }
      
      return result;
    } catch (error) {
      console.error('Erreur backup:create:', error);
      return { success: false, message: 'Erreur lors de la sauvegarde' };
    }
  });
  
  // Restaurer une sauvegarde
  ipcMain.handle('backup:restore', async (event, backupPath) => {
    try {
      // Demander confirmation à l'utilisateur
      const result = await backupService.restoreBackup(backupPath);
      
      if (result.success && mainWindow) {
        mainWindow.webContents.send('backup-notification', {
          type: 'success',
          message: 'Base de données restaurée. L\'application va redémarrer.'
        });
        
        // Redémarrer l'application après un court délai
        setTimeout(() => {
          app.relaunch();
          app.exit();
        }, 2000);
      }
      
      return result;
    } catch (error) {
      console.error('Erreur backup:restore:', error);
      return { success: false, message: 'Erreur lors de la restauration' };
    }
  });
  
  // Obtenir les informations sur la dernière sauvegarde
  ipcMain.handle('backup:get-info', async () => {
    try {
      const lastBackup = backupService.getLastBackupDate();
      const needsBackup = backupService.isBackupNeeded();
      const backupsList = backupService.getBackupsList();
      
      return {
        success: true,
        lastBackup,
        needsBackup,
        backupsList,
        reminderDays: BACKUP_REMINDER_DAYS
      };
    } catch (error) {
      console.error('Erreur backup:get-info:', error);
      return { success: false, message: 'Erreur lors de la récupération des informations' };
    }
  });
  
  // Ouvrir le dossier des sauvegardes
  ipcMain.handle('backup:open-folder', async () => {
    try {
      const backupDir = path.join(process.cwd(), 'backups');
      shell.openPath(backupDir);
      return { success: true };
    } catch (error) {
      console.error('Erreur backup:open-folder:', error);
      return { success: false, message: 'Erreur lors de l\'ouverture du dossier' };
    }
  });
  
  // Supprimer une sauvegarde
  ipcMain.handle('backup:delete', async (event, backupPath) => {
    try {
      const result = backupService.deleteBackup(backupPath);
      return result;
    } catch (error) {
      console.error('Erreur backup:delete:', error);
      return { success: false, message: 'Erreur lors de la suppression' };
    }
  });
  
  // Vérifier la taille de la base de données
  ipcMain.handle('backup:get-db-size', async () => {
    try {
      const db = require('../database/database').getDb();
      const dbPath = db.name;
      const stats = fs.statSync(dbPath);
      
      return {
        success: true,
        size: stats.size,
        path: dbPath
      };
    } catch (error) {
      console.error('Erreur backup:get-db-size:', error);
      return { success: false, message: 'Erreur lors de la récupération de la taille' };
    }
  });
  
  console.log('  → Handler sauvegarde enregistré');
}

module.exports = { register };