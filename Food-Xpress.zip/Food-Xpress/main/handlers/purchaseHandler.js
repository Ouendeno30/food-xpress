const { getDb } = require('../database/database');
const { generatePurchaseNumber, logStockMovement } = require('../utils/helpers');
const { STOCK_MOVEMENT_TYPES } = require('../utils/constants');

function register(ipcMain) {
  
  // Créer un nouvel achat
  ipcMain.handle('purchases:create', async (event, purchaseData) => {
    const db = getDb();
    
    // Démarrer une transaction
    const transaction = db.transaction((purchaseData) => {
      try {
        // Générer le numéro d'achat
        const numeroAchat = generatePurchaseNumber(db);
        
        // Insérer l'entête de l'achat
        const purchaseResult = db.prepare(`
          INSERT INTO achats (
            numero_achat, fournisseur_id, utilisateur_id,
            montant_total, reference_bl, note
          ) VALUES (?, ?, ?, ?, ?, ?)
        `).run(
          numeroAchat,
          purchaseData.fournisseur_id || null,
          event.session.user.userId,
          purchaseData.montant_total,
          purchaseData.reference_bl || null,
          purchaseData.note || null
        );
        
        const achatId = purchaseResult.lastInsertRowid;
        
        // Insérer les lignes d'achat et mettre à jour les stocks
        for (const item of purchaseData.items) {
          // Obtenir le stock avant
          const product = db.prepare('SELECT stock_actuel FROM produits WHERE id = ?').get(item.produit_id);
          const stockAvant = product ? product.stock_actuel : 0;
          const stockApres = stockAvant + item.quantite;
          
          // Insérer la ligne
          db.prepare(`
            INSERT INTO achats_lignes (
              achat_id, produit_id, quantite, 
              prix_achat_unitaire, montant_ligne
            ) VALUES (?, ?, ?, ?, ?)
          `).run(
            achatId,
            item.produit_id,
            item.quantite,
            item.prix_unitaire,
            item.montant
          );
          
          // Mettre à jour le stock (incrémenter)
          db.prepare(`
            UPDATE produits 
            SET stock_actuel = stock_actuel + ?,
                prix_achat = ?,
                updated_at = datetime('now', 'localtime')
            WHERE id = ?
          `).run(item.quantite, item.prix_unitaire, item.produit_id);
          
          // Journaliser le mouvement
          logStockMovement(db, {
            produit_id: item.produit_id,
            type_mouvement: STOCK_MOVEMENT_TYPES.ENTRÉE,
            quantite: item.quantite,
            stock_avant: stockAvant,
            stock_apres: stockApres,
            reference_id: achatId,
            utilisateur_id: event.session.user.userId,
            justification: `Achat n°${numeroAchat}`
          });
        }
        
        return {
          success: true,
          achatId,
          numeroAchat,
          message: 'Achat enregistré avec succès'
        };
        
      } catch (error) {
        throw error;
      }
    });
    
    try {
      const result = transaction(purchaseData);
      return result;
    } catch (error) {
      console.error('Erreur purchases:create:', error);
      return { 
        success: false, 
        message: error.message || 'Erreur lors de l\'enregistrement de l\'achat' 
      };
    }
  });
  
  // Récupérer tous les achats
  ipcMain.handle('purchases:get-all', async (event, filters = {}) => {
    const db = getDb();
    
    try {
      let query = `
        SELECT a.*, f.nom as fournisseur_nom, u.nom_complet as utilisateur_nom,
               COUNT(al.id) as nombre_lignes
        FROM achats a
        LEFT JOIN fournisseurs f ON a.fournisseur_id = f.id
        LEFT JOIN utilisateurs u ON a.utilisateur_id = u.id
        LEFT JOIN achats_lignes al ON a.id = al.achat_id
        WHERE 1=1
      `;
      
      const params = [];
      
      if (filters.date_debut) {
        query += ` AND date(a.date_achat) >= date(?)`;
        params.push(filters.date_debut);
      }
      
      if (filters.date_fin) {
        query += ` AND date(a.date_achat) <= date(?)`;
        params.push(filters.date_fin);
      }
      
      if (filters.fournisseur_id) {
        query += ` AND a.fournisseur_id = ?`;
        params.push(filters.fournisseur_id);
      }
      
      query += ` GROUP BY a.id ORDER BY a.date_achat DESC LIMIT 100`;
      
      const achats = db.prepare(query).all(...params);
      
      return { success: true, data: achats };
    } catch (error) {
      console.error('Erreur purchases:get-all:', error);
      return { success: false, message: 'Erreur lors de la récupération des achats' };
    }
  });
  
  // Récupérer un achat avec ses détails
  ipcMain.handle('purchases:get', async (event, id) => {
    const db = getDb();
    
    try {
      const achat = db.prepare(`
        SELECT a.*, f.nom as fournisseur_nom, u.nom_complet as utilisateur_nom
        FROM achats a
        LEFT JOIN fournisseurs f ON a.fournisseur_id = f.id
        LEFT JOIN utilisateurs u ON a.utilisateur_id = u.id
        WHERE a.id = ?
      `).get(id);
      
      if (!achat) {
        return { success: false, message: 'Achat non trouvé' };
      }
      
      const lignes = db.prepare(`
        SELECT al.*, p.nom as produit_nom, p.reference, p.unite
        FROM achats_lignes al
        JOIN produits p ON al.produit_id = p.id
        WHERE al.achat_id = ?
      `).all(id);
      
      return { 
        success: true, 
        data: { ...achat, lignes } 
      };
    } catch (error) {
      console.error('Erreur purchases:get:', error);
      return { success: false, message: 'Erreur lors de la récupération de l\'achat' };
    }
  });
  
  console.log('  → Handler achats enregistré');
}

module.exports = { register };