const pdfGenerator = require('../services/pdfGenerator');
const { getDb } = require('../database/database');
const { shell } = require('electron');

function register(ipcMain, mainWindow) {
  
  // Générer une facture
  ipcMain.handle('invoice:generate', async (event, venteId) => {
    try {
      const result = await pdfGenerator.generateInvoice(venteId);
      
      if (result.success) {
        return { 
          success: true, 
          filePath: result.filePath,
          message: 'Facture générée avec succès'
        };
      } else {
        return { success: false, message: result.message };
      }
    } catch (error) {
      console.error('Erreur invoice:generate:', error);
      return { success: false, message: 'Erreur lors de la génération de la facture' };
    }
  });
  
  // Ouvrir une facture
  ipcMain.handle('invoice:open', async (event, venteId) => {
    const db = getDb();
    
    try {
      const vente = db.prepare('SELECT pdf_path FROM ventes WHERE id = ?').get(venteId);
      
      if (!vente || !vente.pdf_path) {
        // Générer la facture si elle n'existe pas
        const result = await pdfGenerator.generateInvoice(venteId);
        if (!result.success) {
          return { success: false, message: 'Impossible de générer la facture' };
        }
        shell.openPath(result.filePath);
      } else {
        // Ouvrir le fichier existant
        shell.openPath(vente.pdf_path);
      }
      
      return { success: true };
    } catch (error) {
      console.error('Erreur invoice:open:', error);
      return { success: false, message: 'Erreur lors de l\'ouverture de la facture' };
    }
  });
  
  // Obtenir le chemin d'une facture
  ipcMain.handle('invoice:get-path', async (event, venteId) => {
    const db = getDb();
    
    try {
      const vente = db.prepare('SELECT pdf_path FROM ventes WHERE id = ?').get(venteId);
      
      if (vente && vente.pdf_path) {
        return { success: true, path: vente.pdf_path };
      } else {
        return { success: false, message: 'Facture non trouvée' };
      }
    } catch (error) {
      console.error('Erreur invoice:get-path:', error);
      return { success: false, message: 'Erreur lors de la récupération du chemin' };
    }
  });
  
  console.log('  → Handler factures enregistré');
}

module.exports = { register };