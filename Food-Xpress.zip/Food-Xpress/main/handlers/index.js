const authHandler = require('./authHandler');
const userHandler = require('./userHandler');
const productHandler = require('./productHandler');
const categoryHandler = require('./categoryHandler');
const saleHandler = require('./saleHandler');
const purchaseHandler = require('./purchaseHandler');
const stockHandler = require('./stockHandler');
const dashboardHandler = require('./dashboardHandler');
const invoiceHandler = require('./invoiceHandler');
const backupHandler = require('./backupHandler');
const settingsHandler = require('./settingsHandler');
const licenceHandler = require('./licenceHandler');

function registerHandlers(ipcMain, mainWindow) {
  // Authentification
  authHandler.register(ipcMain);
  
  // Utilisateurs
  userHandler.register(ipcMain);
  
  // Produits
  productHandler.register(ipcMain);
  
  // Catégories
  categoryHandler.register(ipcMain);
  
  // Ventes
  saleHandler.register(ipcMain);
  
  // Achats
  purchaseHandler.register(ipcMain);
  
  // Stock
  stockHandler.register(ipcMain);
  
  // Dashboard
  dashboardHandler.register(ipcMain);
  
  // Factures
  invoiceHandler.register(ipcMain, mainWindow);
  
  // Sauvegarde
  backupHandler.register(ipcMain, mainWindow);
  
  // Paramètres
  settingsHandler.register(ipcMain);
  
  // Licence
  licenceHandler.register(ipcMain);

  console.log('✅ Handlers IPC enregistrés');
}

module.exports = { registerHandlers };