const { getDb } = require('../database/database');
const fs = require('fs');
const path = require('path');

function register(ipcMain) {
  
  // Récupérer les paramètres de l'entreprise
  ipcMain.handle('settings:get-company', async () => {
    const db = getDb();
    
    try {
      const settings = db.prepare('SELECT * FROM parametres_entreprise WHERE id = 1').get();
      
      if (!settings) {
        // Créer les paramètres par défaut
        db.prepare(`
          INSERT INTO parametres_entreprise (id, nom, devise, message_bas_facture)
          VALUES (1, 'FOOD XPRESS', 'GNF', 'Merci de votre confiance ! À bientôt chez FOOD XPRESS')
        `).run();
        
        const newSettings = db.prepare('SELECT * FROM parametres_entreprise WHERE id = 1').get();
        return { success: true, data: newSettings };
      }
      
      return { success: true, data: settings };
    } catch (error) {
      console.error('Erreur settings:get-company:', error);
      return { success: false, message: 'Erreur lors de la récupération des paramètres' };
    }
  });
  
  // Mettre à jour les paramètres de l'entreprise
  ipcMain.handle('settings:update-company', async (event, settings) => {
    const db = getDb();
    
    try {
      // Gérer le logo s'il est fourni (base64)
      let logoPath = settings.logo;
      
      // Si le logo est une chaîne base64, le sauvegarder en fichier
      if (settings.logo && settings.logo.startsWith('data:image')) {
        logoPath = await saveLogoFromBase64(settings.logo);
      }
      
      db.prepare(`
        UPDATE parametres_entreprise SET
          nom = ?,
          logo = ?,
          adresse = ?,
          telephone = ?,
          email = ?,
          devise = ?,
          message_bas_facture = ?,
          updated_at = datetime('now', 'localtime')
        WHERE id = 1
      `).run(
        settings.nom || 'FOOD XPRESS',
        logoPath || null,
        settings.adresse || null,
        settings.telephone || null,
        settings.email || null,
        settings.devise || 'GNF',
        settings.message_bas_facture || 'Merci de votre confiance !'
      );
      
      return { success: true, message: 'Paramètres mis à jour avec succès' };
    } catch (error) {
      console.error('Erreur settings:update-company:', error);
      return { success: false, message: 'Erreur lors de la mise à jour des paramètres' };
    }
  });
  
  // Sauvegarder le logo depuis base64
  async function saveLogoFromBase64(base64String) {
    try {
      // Extraire le type et les données
      const matches = base64String.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
      if (!matches || matches.length !== 3) {
        throw new Error('Format base64 invalide');
      }
      
      const mimeType = matches[1];
      const data = matches[2];
      const buffer = Buffer.from(data, 'base64');
      
      // Déterminer l'extension
      let extension = 'png';
      if (mimeType.includes('jpeg')) extension = 'jpg';
      else if (mimeType.includes('gif')) extension = 'gif';
      else if (mimeType.includes('bmp')) extension = 'bmp';
      
      // Créer le dossier logos s'il n'existe pas
      const logosDir = path.join(process.cwd(), 'renderer', 'assets', 'images', 'logos');
      if (!fs.existsSync(logosDir)) {
        fs.mkdirSync(logosDir, { recursive: true });
      }
      
      // Générer un nom de fichier unique
      const fileName = `logo_${Date.now()}.${extension}`;
      const filePath = path.join(logosDir, fileName);
      
      // Sauvegarder le fichier
      fs.writeFileSync(filePath, buffer);
      
      // Retourner le chemin relatif pour l'affichage
      return `assets/images/logos/${fileName}`;
      
    } catch (error) {
      console.error('Erreur sauvegarde logo:', error);
      throw error;
    }
  }
  
  // Récupérer la version de l'application
  ipcMain.handle('settings:get-version', async () => {
    try {
      const packageJson = require('../../../package.json');
      return { 
        success: true, 
        version: packageJson.version || '2.0.0',
        appName: packageJson.productName || 'FOOD XPRESS'
      };
    } catch (error) {
      console.error('Erreur settings:get-version:', error);
      return { success: false, message: 'Erreur lors de la récupération de la version' };
    }
  });
  
  // Envoyer un message de support (simulé)
  ipcMain.handle('settings:send-support-message', async (event, message) => {
    try {
      // Ici, on pourrait envoyer un email ou sauvegarder le message
      // Pour l'instant, on simule l'envoi
      console.log('Message de support reçu:', message);
      
      // Sauvegarder le message dans un fichier
      const supportDir = path.join(process.cwd(), 'support_messages');
      if (!fs.existsSync(supportDir)) {
        fs.mkdirSync(supportDir, { recursive: true });
      }
      
      const fileName = `message_${Date.now()}.json`;
      const filePath = path.join(supportDir, fileName);
      
      fs.writeFileSync(filePath, JSON.stringify({
        ...message,
        date: new Date().toISOString(),
        user: event.session.user
      }, null, 2));
      
      return { 
        success: true, 
        message: 'Votre message a été envoyé. Nous vous répondrons dans les plus brefs délais.' 
      };
    } catch (error) {
      console.error('Erreur settings:send-support-message:', error);
      return { success: false, message: 'Erreur lors de l\'envoi du message' };
    }
  });
  
  console.log('  → Handler paramètres enregistré');
}

module.exports = { register };