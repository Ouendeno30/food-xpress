const licenceManager = require('../services/licenceManager');

function register(ipcMain) {
  
  // Vérifier le statut de la licence
  ipcMain.handle('licence:check', async () => {
    try {
      return await licenceManager.checkLicence();
    } catch (error) {
      console.error('Erreur licence:check:', error);
      return { activated: false, message: 'Erreur serveur' };
    }
  });
  
  // Activer une licence
  ipcMain.handle('licence:activate', async (event, licenceKey) => {
    try {
      return await licenceManager.activateLicence(licenceKey);
    } catch (error) {
      console.error('Erreur licence:activate:', error);
      return { success: false, message: 'Erreur serveur' };
    }
  });
  
  // Désactiver la licence
  ipcMain.handle('licence:deactivate', async () => {
    try {
      return await licenceManager.deactivateLicence();
    } catch (error) {
      console.error('Erreur licence:deactivate:', error);
      return { success: false, message: 'Erreur serveur' };
    }
  });
  
  // Obtenir les infos de la licence
  ipcMain.handle('licence:get-info', async () => {
    try {
      const info = await licenceManager.getLicenceInfo();
      return { success: true, data: info };
    } catch (error) {
      console.error('Erreur licence:get-info:', error);
      return { success: false, message: 'Erreur serveur' };
    }
  });
  
  console.log('  → Handler licence enregistré');
}

module.exports = { register };