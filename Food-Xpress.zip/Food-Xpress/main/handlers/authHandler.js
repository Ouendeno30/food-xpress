const { getDb } = require('../database/database');
const { comparePassword, hashPassword } = require('../utils/helpers');
const { ROLES, MAX_LOGIN_ATTEMPTS, ERRORS } = require('../utils/constants');
const electronStore = require('../services/storeService');

function register(ipcMain) {
  
  // Connexion utilisateur
  ipcMain.handle('auth:login', async (event, { username, password, rememberMe }) => {
    const db = getDb();
    
    try {
      // Récupérer l'utilisateur
      const user = db.prepare(`
        SELECT * FROM utilisateurs 
        WHERE username = ? AND actif = 1
      `).get(username);
      
      if (!user) {
        return { success: false, message: ERRORS.INVALID_CREDENTIALS };
      }
      
      // Vérifier si le compte est bloqué
      if (user.login_attempts >= MAX_LOGIN_ATTEMPTS) {
        return { success: false, message: ERRORS.ACCOUNT_LOCKED };
      }
      
      // Vérifier le mot de passe
      const passwordValid = comparePassword(password, user.password_hash);
      
      if (!passwordValid) {
        // Incrémenter le compteur de tentatives
        db.prepare(`
          UPDATE utilisateurs 
          SET login_attempts = login_attempts + 1 
          WHERE id = ?
        `).run(user.id);
        
        return { success: false, message: ERRORS.INVALID_CREDENTIALS };
      }
      
      // Réinitialiser les tentatives et mettre à jour last_login
      db.prepare(`
        UPDATE utilisateurs 
        SET login_attempts = 0, last_login = datetime('now', 'localtime')
        WHERE id = ?
      `).run(user.id);
      
      // Créer la session
      const sessionData = {
        userId: user.id,
        username: user.username,
        role: user.role,
        nomComplet: user.nom_complet,
        loginTime: new Date().toISOString()
      };
      
      if (rememberMe) {
        // Sauvegarder le token pour auto-login
        electronStore.set('session', sessionData);
      }
      
      // Stocker dans la session (pour le reste de la session)
      event.session.user = sessionData;
      
      return {
        success: true,
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
          nomComplet: user.nom_complet
        }
      };
      
    } catch (error) {
      console.error('Erreur auth:login:', error);
      return { success: false, message: ERRORS.DATABASE_ERROR };
    }
  });
  
  // Déconnexion
  ipcMain.handle('auth:logout', async (event) => {
    try {
      // Effacer la session
      event.session.user = null;
      electronStore.delete('session');
      return { success: true };
    } catch (error) {
      console.error('Erreur auth:logout:', error);
      return { success: false };
    }
  });
  
  // Vérifier l'authentification
  ipcMain.handle('auth:check', async (event) => {
    try {
      // Vérifier d'abord la session
      if (event.session.user) {
        return {
          authenticated: true,
          user: event.session.user
        };
      }
      
      // Vérifier le token auto-login
      const savedSession = electronStore.get('session');
      if (savedSession) {
        event.session.user = savedSession;
        return {
          authenticated: true,
          user: savedSession
        };
      }
      
      return { authenticated: false };
      
    } catch (error) {
      console.error('Erreur auth:check:', error);
      return { authenticated: false };
    }
  });
  
  // Créer le premier administrateur
  ipcMain.handle('auth:create-first-admin', async (event, userData) => {
    const db = getDb();
    
    try {
      // Vérifier s'il y a déjà des utilisateurs
      const userCount = db.prepare('SELECT COUNT(*) as count FROM utilisateurs').get();
      
      if (userCount.count > 0) {
        return { 
          success: false, 
          message: 'Des utilisateurs existent déjà' 
        };
      }
      
      // Valider les données
      if (!userData.username || !userData.password || !userData.nom_complet) {
        return {
          success: false,
          message: 'Tous les champs sont obligatoires'
        };
      }
      
      if (userData.password.length < 8) {
        return {
          success: false,
          message: 'Le mot de passe doit contenir au moins 8 caractères'
        };
      }
      
      // Hacher le mot de passe
      const hashedPassword = hashPassword(userData.password);
      
      // Créer l'administrateur
      const result = db.prepare(`
        INSERT INTO utilisateurs (username, password_hash, role, nom_complet)
        VALUES (?, ?, ?, ?)
      `).run(
        userData.username,
        hashedPassword,
        ROLES.ADMIN,
        userData.nom_complet
      );
      
      return {
        success: true,
        message: 'Administrateur créé avec succès',
        userId: result.lastInsertRowid
      };
      
    } catch (error) {
      console.error('Erreur auth:create-first-admin:', error);
      
      // Vérifier si c'est une erreur d'unicité
      if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
        return {
          success: false,
          message: 'Ce nom d\'utilisateur est déjà pris'
        };
      }
      
      return { success: false, message: ERRORS.DATABASE_ERROR };
    }
  });
  
  // Obtenir l'utilisateur courant
  ipcMain.handle('auth:get-current-user', async (event) => {
    try {
      if (event.session.user) {
        return { success: true, user: event.session.user };
      }
      return { success: false, message: 'Non connecté' };
    } catch (error) {
      console.error('Erreur auth:get-current-user:', error);
      return { success: false, message: ERRORS.DATABASE_ERROR };
    }
  });
  
  console.log('  → Handler auth enregistré');
}

module.exports = { register };