const { getDb } = require('../database/database');
const { generateInvoiceNumber, logStockMovement } = require('../utils/helpers');
const { STOCK_MOVEMENT_TYPES, ERRORS } = require('../utils/constants');

function register(ipcMain) {
  
  // Créer une nouvelle vente
  ipcMain.handle('sales:create', async (event, saleData) => {
    const db = getDb();
    
    // Démarrer une transaction
    const transaction = db.transaction((saleData) => {
      try {
        // Vérifier les stocks pour chaque produit
        for (const item of saleData.items) {
          const product = db.prepare(`
            SELECT stock_actuel, nom FROM produits 
            WHERE id = ? AND actif = 1
          `).get(item.produit_id);
          
          if (!product) {
            throw new Error(`Produit ID ${item.produit_id} non trouvé`);
          }
          
          if (product.stock_actuel < item.quantite) {
            throw new Error(`Stock insuffisant pour ${product.nom} (dispo: ${product.stock_actuel})`);
          }
        }
        
        // Générer le numéro de facture
        const numeroFacture = generateInvoiceNumber(db);
        
        // Insérer l'entête de la vente
        const saleResult = db.prepare(`
          INSERT INTO ventes (
            numero_facture, utilisateur_id, client_nom, client_contact,
            montant_total, montant_paye, monnaie_rendue
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(
          numeroFacture,
          event.session.user.userId,
          saleData.client_nom || null,
          saleData.client_contact || null,
          saleData.montant_total,
          saleData.montant_paye,
          saleData.monnaie_rendue
        );
        
        const venteId = saleResult.lastInsertRowid;
        
        // Insérer les lignes de vente et mettre à jour les stocks
        for (const item of saleData.items) {
          // Obtenir le stock avant
          const product = db.prepare('SELECT stock_actuel FROM produits WHERE id = ?').get(item.produit_id);
          const stockAvant = product.stock_actuel;
          const stockApres = stockAvant - item.quantite;
          
          // Insérer la ligne
          db.prepare(`
            INSERT INTO ventes_lignes (
              vente_id, produit_id, quantite, 
              prix_vente_unitaire, montant_ligne
            ) VALUES (?, ?, ?, ?, ?)
          `).run(
            venteId,
            item.produit_id,
            item.quantite,
            item.prix_unitaire,
            item.montant
          );
          
          // Mettre à jour le stock
          db.prepare(`
            UPDATE produits 
            SET stock_actuel = stock_actuel - ? 
            WHERE id = ?
          `).run(item.quantite, item.produit_id);
          
          // Journaliser le mouvement
          logStockMovement(db, {
            produit_id: item.produit_id,
            type_mouvement: STOCK_MOVEMENT_TYPES.SORTIE,
            quantite: item.quantite,
            stock_avant: stockAvant,
            stock_apres: stockApres,
            reference_id: venteId,
            utilisateur_id: event.session.user.userId,
            justification: `Vente n°${numeroFacture}`
          });
        }
        
        return {
          success: true,
          venteId,
          numeroFacture,
          message: 'Vente enregistrée avec succès'
        };
        
      } catch (error) {
        throw error;
      }
    });
    
    try {
      const result = transaction(saleData);
      return result;
    } catch (error) {
      console.error('Erreur sales:create:', error);
      return { 
        success: false, 
        message: error.message || 'Erreur lors de l\'enregistrement de la vente' 
      };
    }
  });
  
  // Récupérer toutes les ventes
  ipcMain.handle('sales:get-all', async (event, filters = {}) => {
    const db = getDb();
    
    try {
      let query = `
        SELECT v.*, u.nom_complet as vendeur_nom,
               COUNT(vl.id) as nombre_articles
        FROM ventes v
        LEFT JOIN utilisateurs u ON v.utilisateur_id = u.id
        LEFT JOIN ventes_lignes vl ON v.id = vl.vente_id
        WHERE 1=1
      `;
      
      const params = [];
      
      if (filters.date_debut) {
        query += ` AND date(v.date_vente) >= date(?)`;
        params.push(filters.date_debut);
      }
      
      if (filters.date_fin) {
        query += ` AND date(v.date_vente) <= date(?)`;
        params.push(filters.date_fin);
      }
      
      if (filters.utilisateur_id) {
        query += ` AND v.utilisateur_id = ?`;
        params.push(filters.utilisateur_id);
      }
      
      query += ` GROUP BY v.id ORDER BY v.date_vente DESC LIMIT 100`;
      
      const ventes = db.prepare(query).all(...params);
      
      return { success: true, data: ventes };
    } catch (error) {
      console.error('Erreur sales:get-all:', error);
      return { success: false, message: 'Erreur lors de la récupération des ventes' };
    }
  });
  
  // Récupérer une vente avec ses détails
  ipcMain.handle('sales:get', async (event, id) => {
    const db = getDb();
    
    try {
      const vente = db.prepare(`
        SELECT v.*, u.nom_complet as vendeur_nom
        FROM ventes v
        LEFT JOIN utilisateurs u ON v.utilisateur_id = u.id
        WHERE v.id = ?
      `).get(id);
      
      if (!vente) {
        return { success: false, message: 'Vente non trouvée' };
      }
      
      const lignes = db.prepare(`
        SELECT vl.*, p.nom as produit_nom, p.reference, p.unite
        FROM ventes_lignes vl
        JOIN produits p ON vl.produit_id = p.id
        WHERE vl.vente_id = ?
      `).all(id);
      
      return { 
        success: true, 
        data: { ...vente, lignes } 
      };
    } catch (error) {
      console.error('Erreur sales:get:', error);
      return { success: false, message: 'Erreur lors de la récupération de la vente' };
    }
  });
  
  // Récupérer les ventes du jour
  ipcMain.handle('sales:get-today', async () => {
    const db = getDb();
    
    try {
      const ventes = db.prepare(`
        SELECT v.*, u.nom_complet as vendeur_nom
        FROM ventes v
        LEFT JOIN utilisateurs u ON v.utilisateur_id = u.id
        WHERE date(v.date_vente) = date('now', 'localtime')
        ORDER BY v.date_vente DESC
      `).all();
      
      // Calculer le total du jour
      const totals = db.prepare(`
        SELECT 
          COUNT(*) as nombre_ventes,
          SUM(montant_total) as total_ca,
          SUM(montant_paye) as total_encaisse
        FROM ventes
        WHERE date(date_vente) = date('now', 'localtime')
      `).get();
      
      return { 
        success: true, 
        data: ventes,
        totals: totals || { nombre_ventes: 0, total_ca: 0, total_encaisse: 0 }
      };
    } catch (error) {
      console.error('Erreur sales:get-today:', error);
      return { success: false, message: 'Erreur lors de la récupération des ventes' };
    }
  });
  
  // Récupérer les ventes par période
  ipcMain.handle('sales:by-period', async (event, periode) => {
    const db = getDb();
    
    try {
      let groupBy, dateFormat;
      switch(periode) {
        case 'day':
          groupBy = 'strftime(\'%Y-%m-%d\', date_vente)';
          dateFormat = '%Y-%m-%d';
          break;
        case 'week':
          groupBy = 'strftime(\'%Y-%W\', date_vente)';
          dateFormat = 'Semaine %W %Y';
          break;
        case 'month':
          groupBy = 'strftime(\'%Y-%m\', date_vente)';
          dateFormat = '%m/%Y';
          break;
        default:
          groupBy = 'strftime(\'%Y-%m-%d\', date_vente)';
      }
      
      const stats = db.prepare(`
        SELECT 
          ${groupBy} as periode,
          COUNT(*) as nombre_ventes,
          SUM(montant_total) as total_ca,
          AVG(montant_total) as panier_moyen
        FROM ventes
        GROUP BY periode
        ORDER BY periode DESC
        LIMIT 30
      `).all();
      
      return { success: true, data: stats };
    } catch (error) {
      console.error('Erreur sales:by-period:', error);
      return { success: false, message: 'Erreur lors de la récupération des statistiques' };
    }
  });
  
  console.log('  → Handler ventes enregistré');
}

module.exports = { register };