const { getDb } = require('../database/database');
const { hashPassword, comparePassword } = require('../utils/helpers');
const { ROLES, MAX_LOGIN_ATTEMPTS, ERRORS } = require('../utils/constants');

function register(ipcMain) {
  
  // Récupérer tous les utilisateurs (admin uniquement)
  ipcMain.handle('users:get-all', async (event) => {
    const db = getDb();
    
    // Vérifier que l'utilisateur est admin
    if (!event.session.user || event.session.user.role !== ROLES.ADMIN) {
      return { success: false, message: ERRORS.UNAUTHORIZED };
    }
    
    try {
      const users = db.prepare(`
        SELECT id, username, role, nom_complet, actif, 
               created_at, last_login, login_attempts
        FROM utilisateurs
        ORDER BY 
          CASE WHEN role = 'admin' THEN 0 ELSE 1 END,
          nom_complet ASC
      `).all();
      
      return { success: true, data: users };
    } catch (error) {
      console.error('Erreur users:get-all:', error);
      return { success: false, message: 'Erreur lors de la récupération des utilisateurs' };
    }
  });
  
  // Créer un utilisateur (admin uniquement)
  ipcMain.handle('users:create', async (event, userData) => {
    const db = getDb();
    
    if (!event.session.user || event.session.user.role !== ROLES.ADMIN) {
      return { success: false, message: ERRORS.UNAUTHORIZED };
    }
    
    try {
      // Valider les données
      if (!userData.username || !userData.password || !userData.nom_complet) {
        return {
          success: false,
          message: 'Tous les champs sont obligatoires'
        };
      }
      
      if (userData.password.length < 8) {
        return {
          success: false,
          message: 'Le mot de passe doit contenir au moins 8 caractères'
        };
      }
      
      // Vérifier si le nom d'utilisateur existe déjà
      const existing = db.prepare('SELECT id FROM utilisateurs WHERE username = ?').get(userData.username);
      if (existing) {
        return { success: false, message: 'Ce nom d\'utilisateur existe déjà' };
      }
      
      // Hacher le mot de passe
      const hashedPassword = hashPassword(userData.password);
      
      // Créer l'utilisateur
      const result = db.prepare(`
        INSERT INTO utilisateurs (username, password_hash, role, nom_complet, actif)
        VALUES (?, ?, ?, ?, ?)
      `).run(
        userData.username,
        hashedPassword,
        userData.role || ROLES.VENDEUR,
        userData.nom_complet,
        userData.actif !== undefined ? (userData.actif ? 1 : 0) : 1
      );
      
      return {
        success: true,
        message: 'Utilisateur créé avec succès',
        userId: result.lastInsertRowid
      };
      
    } catch (error) {
      console.error('Erreur users:create:', error);
      return { success: false, message: 'Erreur lors de la création de l\'utilisateur' };
    }
  });
  
  // Mettre à jour un utilisateur (admin uniquement)
  ipcMain.handle('users:update', async (event, userData) => {
    const db = getDb();
    
    if (!event.session.user || event.session.user.role !== ROLES.ADMIN) {
      return { success: false, message: ERRORS.UNAUTHORIZED };
    }
    
    try {
      // Vérifier que l'utilisateur existe
      const existing = db.prepare('SELECT * FROM utilisateurs WHERE id = ?').get(userData.id);
      if (!existing) {
        return { success: false, message: 'Utilisateur non trouvé' };
      }
      
      // Vérifier si le nouveau nom d'utilisateur est déjà pris
      if (userData.username && userData.username !== existing.username) {
        const usernameExists = db.prepare(
          'SELECT id FROM utilisateurs WHERE username = ? AND id != ?'
        ).get(userData.username, userData.id);
        
        if (usernameExists) {
          return { success: false, message: 'Ce nom d\'utilisateur existe déjà' };
        }
      }
      
      // Construire la requête de mise à jour
      let query = 'UPDATE utilisateurs SET ';
      const params = [];
      const updates = [];
      
      if (userData.nom_complet) {
        updates.push('nom_complet = ?');
        params.push(userData.nom_complet);
      }
      
      if (userData.username) {
        updates.push('username = ?');
        params.push(userData.username);
      }
      
      if (userData.role) {
        updates.push('role = ?');
        params.push(userData.role);
      }
      
      if (userData.actif !== undefined) {
        updates.push('actif = ?');
        params.push(userData.actif ? 1 : 0);
      }
      
      if (userData.password) {
        if (userData.password.length < 8) {
          return {
            success: false,
            message: 'Le mot de passe doit contenir au moins 8 caractères'
          };
        }
        updates.push('password_hash = ?');
        params.push(hashPassword(userData.password));
      }
      
      if (updates.length === 0) {
        return { success: false, message: 'Aucune donnée à mettre à jour' };
      }
      
      query += updates.join(', ') + ' WHERE id = ?';
      params.push(userData.id);
      
      db.prepare(query).run(...params);
      
      return { success: true, message: 'Utilisateur mis à jour avec succès' };
      
    } catch (error) {
      console.error('Erreur users:update:', error);
      return { success: false, message: 'Erreur lors de la mise à jour de l\'utilisateur' };
    }
  });
  
  // Supprimer/désactiver un utilisateur (admin uniquement)
  ipcMain.handle('users:delete', async (event, userId) => {
    const db = getDb();
    
    if (!event.session.user || event.session.user.role !== ROLES.ADMIN) {
      return { success: false, message: ERRORS.UNAUTHORIZED };
    }
    
    try {
      // Empêcher la suppression de son propre compte
      if (userId === event.session.user.userId) {
        return { success: false, message: 'Vous ne pouvez pas supprimer votre propre compte' };
      }
      
      // Vérifier si l'utilisateur a des transactions
      const sales = db.prepare('SELECT COUNT(*) as count FROM ventes WHERE utilisateur_id = ?').get(userId);
      const purchases = db.prepare('SELECT COUNT(*) as count FROM achats WHERE utilisateur_id = ?').get(userId);
      const movements = db.prepare('SELECT COUNT(*) as count FROM mouvements_stock WHERE utilisateur_id = ?').get(userId);
      
      if (sales.count > 0 || purchases.count > 0 || movements.count > 0) {
        // Désactiver plutôt que supprimer
        db.prepare('UPDATE utilisateurs SET actif = 0 WHERE id = ?').run(userId);
        return { 
          success: true, 
          message: 'Utilisateur désactivé (des transactions existent)',
          deactivated: true
        };
      } else {
        // Suppression physique possible
        db.prepare('DELETE FROM utilisateurs WHERE id = ?').run(userId);
        return { success: true, message: 'Utilisateur supprimé définitivement' };
      }
      
    } catch (error) {
      console.error('Erreur users:delete:', error);
      return { success: false, message: 'Erreur lors de la suppression de l\'utilisateur' };
    }
  });
  
  // Débloquer un utilisateur (admin uniquement)
  ipcMain.handle('users:unlock', async (event, userId) => {
    const db = getDb();
    
    if (!event.session.user || event.session.user.role !== ROLES.ADMIN) {
      return { success: false, message: ERRORS.UNAUTHORIZED };
    }
    
    try {
      db.prepare('UPDATE utilisateurs SET login_attempts = 0 WHERE id = ?').run(userId);
      return { success: true, message: 'Compte débloqué avec succès' };
    } catch (error) {
      console.error('Erreur users:unlock:', error);
      return { success: false, message: 'Erreur lors du déblocage du compte' };
    }
  });
  
  // Réinitialiser le mot de passe (admin uniquement)
  ipcMain.handle('users:reset-password', async (event, userId, newPassword) => {
    const db = getDb();
    
    if (!event.session.user || event.session.user.role !== ROLES.ADMIN) {
      return { success: false, message: ERRORS.UNAUTHORIZED };
    }
    
    try {
      if (!newPassword || newPassword.length < 8) {
        return {
          success: false,
          message: 'Le mot de passe doit contenir au moins 8 caractères'
        };
      }
      
      const hashedPassword = hashPassword(newPassword);
      db.prepare('UPDATE utilisateurs SET password_hash = ?, login_attempts = 0 WHERE id = ?')
        .run(hashedPassword, userId);
      
      return { success: true, message: 'Mot de passe réinitialisé avec succès' };
      
    } catch (error) {
      console.error('Erreur users:reset-password:', error);
      return { success: false, message: 'Erreur lors de la réinitialisation du mot de passe' };
    }
  });
  
  console.log('  → Handler utilisateurs enregistré');
}

module.exports = { register };