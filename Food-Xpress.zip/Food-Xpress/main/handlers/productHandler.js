const { getDb } = require('../database/database');
const { logStockMovement } = require('../utils/helpers');
const { STOCK_MOVEMENT_TYPES } = require('../utils/constants');

function register(ipcMain) {
  
  // Récupérer tous les produits
  ipcMain.handle('products:get-all', async () => {
    const db = getDb();
    
    try {
      const products = db.prepare(`
        SELECT p.*, c.nom as categorie_nom 
        FROM produits p
        LEFT JOIN categories c ON p.categorie_id = c.id
        WHERE p.actif = 1
        ORDER BY p.nom ASC
      `).all();
      
      return { success: true, data: products };
    } catch (error) {
      console.error('Erreur products:get-all:', error);
      return { success: false, message: 'Erreur lors de la récupération des produits' };
    }
  });
  
  // Récupérer un produit par ID
  ipcMain.handle('products:get', async (event, id) => {
    const db = getDb();
    
    try {
      const product = db.prepare(`
        SELECT p.*, c.nom as categorie_nom 
        FROM produits p
        LEFT JOIN categories c ON p.categorie_id = c.id
        WHERE p.id = ? AND p.actif = 1
      `).get(id);
      
      if (!product) {
        return { success: false, message: 'Produit non trouvé' };
      }
      
      return { success: true, data: product };
    } catch (error) {
      console.error('Erreur products:get:', error);
      return { success: false, message: 'Erreur lors de la récupération du produit' };
    }
  });
  
  // Créer un produit
  ipcMain.handle('products:create', async (event, productData) => {
    const db = getDb();
    
    try {
      // Générer une référence si non fournie
      if (!productData.reference) {
        const lastRef = db.prepare(`
          SELECT reference FROM produits 
          WHERE reference LIKE 'PROD-%'
          ORDER BY id DESC LIMIT 1
        `).get();
        
        let nextNum = 1;
        if (lastRef) {
          const num = parseInt(lastRef.reference.split('-')[1]);
          nextNum = num + 1;
        }
        productData.reference = `PROD-${String(nextNum).padStart(4, '0')}`;
      }
      
      // Vérifier si la référence existe déjà
      const existing = db.prepare('SELECT id FROM produits WHERE reference = ?').get(productData.reference);
      if (existing) {
        return { success: false, message: 'Cette référence existe déjà' };
      }
      
      // Valider les prix
      if (productData.prix_vente < productData.prix_achat) {
        return { 
          success: false, 
          message: 'Le prix de vente ne peut pas être inférieur au prix d\'achat',
          warning: true
        };
      }
      
      const result = db.prepare(`
        INSERT INTO produits (
          reference, nom, categorie_id, prix_achat, prix_vente, 
          unite, seuil_alerte, stock_actuel
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        productData.reference,
        productData.nom,
        productData.categorie_id || null,
        productData.prix_achat || 0,
        productData.prix_vente || 0,
        productData.unite || 'piece',
        productData.seuil_alerte || 5,
        productData.stock_initial || 0
      );
      
      // Si stock initial > 0, enregistrer le mouvement
      if (productData.stock_initial > 0) {
        logStockMovement(db, {
          produit_id: result.lastInsertRowid,
          type_mouvement: STOCK_MOVEMENT_TYPES.ENTRÉE,
          quantite: productData.stock_initial,
          stock_avant: 0,
          stock_apres: productData.stock_initial,
          reference_id: null,
          utilisateur_id: event.session.user?.userId,
          justification: 'Stock initial'
        });
      }
      
      return { 
        success: true, 
        message: 'Produit créé avec succès',
        id: result.lastInsertRowid,
        reference: productData.reference
      };
    } catch (error) {
      console.error('Erreur products:create:', error);
      return { success: false, message: 'Erreur lors de la création du produit' };
    }
  });
  
  // Mettre à jour un produit
  ipcMain.handle('products:update', async (event, productData) => {
    const db = getDb();
    
    try {
      // Vérifier que le produit existe
      const existing = db.prepare('SELECT * FROM produits WHERE id = ?').get(productData.id);
      if (!existing) {
        return { success: false, message: 'Produit non trouvé' };
      }
      
      // Valider les prix
      if (productData.prix_vente < productData.prix_achat) {
        return { 
          success: false, 
          message: 'Le prix de vente ne peut pas être inférieur au prix d\'achat',
          warning: true
        };
      }
      
      db.prepare(`
        UPDATE produits SET
          nom = ?,
          categorie_id = ?,
          prix_achat = ?,
          prix_vente = ?,
          unite = ?,
          seuil_alerte = ?,
          updated_at = datetime('now', 'localtime')
        WHERE id = ?
      `).run(
        productData.nom,
        productData.categorie_id || null,
        productData.prix_achat,
        productData.prix_vente,
        productData.unite,
        productData.seuil_alerte,
        productData.id
      );
      
      return { success: true, message: 'Produit mis à jour avec succès' };
    } catch (error) {
      console.error('Erreur products:update:', error);
      return { success: false, message: 'Erreur lors de la mise à jour du produit' };
    }
  });
  
  // Archiver (supprimer logiquement) un produit
  ipcMain.handle('products:delete', async (event, productId) => {
    const db = getDb();
    
    try {
      // Vérifier si le produit est utilisé dans des transactions
      const inPurchases = db.prepare(`
        SELECT COUNT(*) as count FROM achats_lignes WHERE produit_id = ?
      `).get(productId);
      
      const inSales = db.prepare(`
        SELECT COUNT(*) as count FROM ventes_lignes WHERE produit_id = ?
      `).get(productId);
      
      if (inPurchases.count > 0 || inSales.count > 0) {
        // Archive le produit
        db.prepare('UPDATE produits SET actif = 0 WHERE id = ?').run(productId);
        return { 
          success: true, 
          message: 'Produit archivé car il a déjà été utilisé dans des transactions',
          archived: true
        };
      } else {
        // Suppression physique possible
        db.prepare('DELETE FROM produits WHERE id = ?').run(productId);
        return { success: true, message: 'Produit supprimé définitivement' };
      }
    } catch (error) {
      console.error('Erreur products:delete:', error);
      return { success: false, message: 'Erreur lors de la suppression du produit' };
    }
  });
  
  // Récupérer les produits par catégorie
  ipcMain.handle('products:by-category', async (event, categoryId) => {
    const db = getDb();
    
    try {
      const products = db.prepare(`
        SELECT * FROM produits 
        WHERE categorie_id = ? AND actif = 1
        ORDER BY nom ASC
      `).all(categoryId);
      
      return { success: true, data: products };
    } catch (error) {
      console.error('Erreur products:by-category:', error);
      return { success: false, message: 'Erreur lors de la récupération des produits' };
    }
  });
  
  // Rechercher des produits
  ipcMain.handle('products:search', async (event, query) => {
    const db = getDb();
    
    try {
      const searchTerm = `%${query}%`;
      const products = db.prepare(`
        SELECT p.*, c.nom as categorie_nom 
        FROM produits p
        LEFT JOIN categories c ON p.categorie_id = c.id
        WHERE p.actif = 1 
          AND (p.nom LIKE ? OR p.reference LIKE ?)
        ORDER BY p.nom ASC
        LIMIT 50
      `).all(searchTerm, searchTerm);
      
      return { success: true, data: products };
    } catch (error) {
      console.error('Erreur products:search:', error);
      return { success: false, message: 'Erreur lors de la recherche' };
    }
  });
  
  console.log('  → Handler produits enregistré');
}

module.exports = { register };