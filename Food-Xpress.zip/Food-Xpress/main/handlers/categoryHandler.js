const { getDb } = require('../database/database');

function register(ipcMain) {
  
  // Récupérer toutes les catégories
  ipcMain.handle('categories:get-all', async () => {
    const db = getDb();
    
    try {
      const categories = db.prepare(`
        SELECT c.*, COUNT(p.id) as nombre_produits
        FROM categories c
        LEFT JOIN produits p ON c.id = p.categorie_id AND p.actif = 1
        GROUP BY c.id
        ORDER BY c.nom ASC
      `).all();
      
      return { success: true, data: categories };
    } catch (error) {
      console.error('Erreur categories:get-all:', error);
      return { success: false, message: 'Erreur lors de la récupération des catégories' };
    }
  });
  
  // Créer une catégorie
  ipcMain.handle('categories:create', async (event, categoryData) => {
    const db = getDb();
    
    try {
      // Vérifier si le nom existe déjà
      const existing = db.prepare('SELECT id FROM categories WHERE nom = ?').get(categoryData.nom);
      if (existing) {
        return { success: false, message: 'Cette catégorie existe déjà' };
      }
      
      const result = db.prepare(`
        INSERT INTO categories (nom, description)
        VALUES (?, ?)
      `).run(categoryData.nom, categoryData.description || null);
      
      return { 
        success: true, 
        message: 'Catégorie créée avec succès',
        id: result.lastInsertRowid
      };
    } catch (error) {
      console.error('Erreur categories:create:', error);
      return { success: false, message: 'Erreur lors de la création de la catégorie' };
    }
  });
  
  // Mettre à jour une catégorie
  ipcMain.handle('categories:update', async (event, categoryData) => {
    const db = getDb();
    
    try {
      // Vérifier si le nom existe déjà pour une autre catégorie
      const existing = db.prepare(`
        SELECT id FROM categories 
        WHERE nom = ? AND id != ?
      `).get(categoryData.nom, categoryData.id);
      
      if (existing) {
        return { success: false, message: 'Cette catégorie existe déjà' };
      }
      
      db.prepare(`
        UPDATE categories SET
          nom = ?,
          description = ?
        WHERE id = ?
      `).run(
        categoryData.nom,
        categoryData.description || null,
        categoryData.id
      );
      
      return { success: true, message: 'Catégorie mise à jour avec succès' };
    } catch (error) {
      console.error('Erreur categories:update:', error);
      return { success: false, message: 'Erreur lors de la mise à jour de la catégorie' };
    }
  });
  
  // Supprimer une catégorie
  ipcMain.handle('categories:delete', async (event, categoryId) => {
    const db = getDb();
    
    try {
      // Vérifier si la catégorie contient des produits
      const products = db.prepare(`
        SELECT COUNT(*) as count FROM produits 
        WHERE categorie_id = ? AND actif = 1
      `).get(categoryId);
      
      if (products.count > 0) {
        return { 
          success: false, 
          message: 'Impossible de supprimer : la catégorie contient des produits'
        };
      }
      
      db.prepare('DELETE FROM categories WHERE id = ?').run(categoryId);
      
      return { success: true, message: 'Catégorie supprimée avec succès' };
    } catch (error) {
      console.error('Erreur categories:delete:', error);
      return { success: false, message: 'Erreur lors de la suppression de la catégorie' };
    }
  });
  
  console.log('  → Handler catégories enregistré');
}

module.exports = { register };