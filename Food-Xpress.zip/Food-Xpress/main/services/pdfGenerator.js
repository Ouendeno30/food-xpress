const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');
const { getDb } = require('../database/database');
const { ensureDir, formatPrice, formatDate } = require('../utils/helpers');

class PDFGenerator {
  
  async generateInvoice(venteId) {
    const db = getDb();
    
    try {
      // Récupérer les données de la vente
      const vente = db.prepare(`
        SELECT v.*, u.nom_complet as vendeur_nom
        FROM ventes v
        JOIN utilisateurs u ON v.utilisateur_id = u.id
        WHERE v.id = ?
      `).get(venteId);
      
      if (!vente) {
        throw new Error('Vente non trouvée');
      }
      
      // Récupérer les lignes de vente
      const lignes = db.prepare(`
        SELECT vl.*, p.nom as produit_nom, p.reference, p.unite
        FROM ventes_lignes vl
        JOIN produits p ON vl.produit_id = p.id
        WHERE vl.vente_id = ?
      `).all(venteId);
      
      // Récupérer les paramètres entreprise
      const company = db.prepare('SELECT * FROM parametres_entreprise WHERE id = 1').get() || {};
      
      // Créer le dossier invoices s'il n'existe pas
      const invoicesDir = path.join(process.cwd(), 'invoices');
      ensureDir(invoicesDir);
      
      // Créer le sous-dossier par année/mois
      const date = new Date(vente.date_vente);
      const yearMonth = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      const monthDir = path.join(invoicesDir, yearMonth);
      ensureDir(monthDir);
      
      // Nom du fichier
      const fileName = `${vente.numero_facture.replace(/\//g, '-')}.pdf`;
      const filePath = path.join(monthDir, fileName);
      
      // Créer le PDF
      const doc = new PDFDocument({ margin: 50, size: 'A4' });
      const stream = fs.createWriteStream(filePath);
      doc.pipe(stream);
      
      // En-tête
      this.drawHeader(doc, company, vente);
      
      // Informations client
      this.drawClientInfo(doc, vente);
      
      // Tableau des produits
      this.drawProductsTable(doc, lignes);
      
      // Totaux
      this.drawTotals(doc, vente);
      
      // Pied de page
      this.drawFooter(doc, company, vente);
      
      // Finaliser le PDF
      doc.end();
      
      // Attendre que l'écriture soit terminée
      await new Promise((resolve, reject) => {
        stream.on('finish', resolve);
        stream.on('error', reject);
      });
      
      // Mettre à jour le chemin PDF dans la base de données
      db.prepare('UPDATE ventes SET pdf_path = ? WHERE id = ?').run(filePath, venteId);
      
      return { success: true, filePath };
      
    } catch (error) {
      console.error('Erreur génération PDF:', error);
      return { success: false, message: error.message };
    }
  }
  
  drawHeader(doc, company, vente) {
    // Logo (placeholder)
    doc.rect(50, 45, 100, 60).stroke('#667eea');
    doc.fontSize(10).fillColor('#667eea').text('LOGO', 90, 70);
    
    // Titre
    doc.fontSize(20).fillColor('#333').text(
      company.nom || 'FOOD XPRESS',
      200, 50,
      { align: 'right', width: 350 }
    );
    
    // Coordonnées entreprise
    doc.fontSize(10).fillColor('#666');
    let y = 70;
    if (company.adresse) {
      doc.text(company.adresse, 200, y, { align: 'right', width: 350 });
      y += 15;
    }
    if (company.telephone) {
      doc.text(`Tél: ${company.telephone}`, 200, y, { align: 'right', width: 350 });
      y += 15;
    }
    if (company.email) {
      doc.text(`Email: ${company.email}`, 200, y, { align: 'right', width: 350 });
    }
    
    // Ligne de séparation
    doc.moveTo(50, 120).lineTo(550, 120).stroke('#eee');
  }
  
  drawClientInfo(doc, vente) {
    let y = 140;
    
    // Titre facture
    doc.fontSize(16).fillColor('#333').text('FACTURE', 50, y);
    y += 30;
    
    // Numéro et date
    doc.fontSize(10);
    doc.fillColor('#666').text(`N° ${vente.numero_facture}`, 50, y);
    doc.text(`Date: ${formatDate(vente.date_vente, true)}`, 50, y + 15);
    
    // Informations client
    if (vente.client_nom) {
      doc.fillColor('#333').text('CLIENT', 400, y);
      doc.fillColor('#666');
      doc.text(vente.client_nom, 400, y + 15);
      if (vente.client_contact) {
        doc.text(`Tél: ${vente.client_contact}`, 400, y + 30);
      }
    }
    
    y += 70;
    
    // Tableau des produits
    this.drawTableHeader(doc, y);
  }
  
  drawTableHeader(doc, y) {
    // Fond d'en-tête
    doc.rect(50, y - 5, 500, 25).fill('#667eea');
    
    // Texte en-tête
    doc.fontSize(10).fillColor('white');
    doc.text('Désignation', 60, y);
    doc.text('Qté', 250, y, { width: 50, align: 'right' });
    doc.text('P.U.', 320, y, { width: 80, align: 'right' });
    doc.text('Total', 450, y, { width: 80, align: 'right' });
  }
  
  drawProductsTable(doc, lignes) {
    let y = 150; // À ajuster selon le contenu précédent
    let rowY = y + 25;
    
    lignes.forEach((ligne, index) => {
      if (rowY > 700) {
        // Nouvelle page si nécessaire
        doc.addPage();
        rowY = 50;
        this.drawTableHeader(doc, rowY);
        rowY += 25;
      }
      
      // Alterner les couleurs de fond
      if (index % 2 === 0) {
        doc.rect(50, rowY - 5, 500, 20).fill('#f8fafc');
      }
      
      doc.fillColor('#333').fontSize(9);
      
      // Désignation (avec retour à la ligne si trop long)
      const designation = ligne.produit_nom;
      if (designation.length > 35) {
        doc.text(designation.substring(0, 35) + '...', 60, rowY);
      } else {
        doc.text(designation, 60, rowY);
      }
      
      // Quantité
      doc.text(
        `${ligne.quantite} ${ligne.unite}`,
        250, rowY,
        { width: 50, align: 'right' }
      );
      
      // Prix unitaire
      doc.text(
        formatPrice(ligne.prix_vente_unitaire, true),
        320, rowY,
        { width: 80, align: 'right' }
      );
      
      // Total ligne
      doc.text(
        formatPrice(ligne.montant_ligne, true),
        450, rowY,
        { width: 80, align: 'right' }
      );
      
      rowY += 20;
    });
    
    return rowY;
  }
  
  drawTotals(doc, vente) {
    let y = 650; // À ajuster
    
    // Ligne de séparation
    doc.moveTo(350, y).lineTo(550, y).stroke('#ddd');
    y += 10;
    
    // Sous-total
    doc.fontSize(10);
    doc.fillColor('#666').text('Sous-total:', 350, y);
    doc.fillColor('#333').text(
      formatPrice(vente.montant_total, true),
      450, y,
      { width: 80, align: 'right' }
    );
    y += 20;
    
    // Total
    doc.fontSize(12);
    doc.fillColor('#333').text('TOTAL TTC:', 350, y);
    doc.fillColor('#667eea').font('Helvetica-Bold').text(
      formatPrice(vente.montant_total),
      450, y,
      { width: 80, align: 'right' }
    );
    y += 25;
    
    // Montant payé et monnaie
    doc.font('Helvetica').fontSize(10).fillColor('#666');
    doc.text(`Montant payé: ${formatPrice(vente.montant_paye)}`, 350, y);
    y += 15;
    doc.text(`Monnaie rendue: ${formatPrice(vente.monnaie_rendue)}`, 350, y);
  }
  
  drawFooter(doc, company, vente) {
    // Pied de page
    const y = 750;
    
    doc.fontSize(8).fillColor('#999');
    
    // Message de remerciement
    if (company.message_bas_facture) {
      doc.text(company.message_bas_facture, 50, y, { align: 'center', width: 500 });
    }
    
    // Mentions légales
    doc.fontSize(7).fillColor('#ccc');
    doc.text(
      `Facture générée le ${formatDate(new Date(), true)} par ${vente.vendeur_nom}`,
      50, y + 20,
      { align: 'center', width: 500 }
    );
    
    // Crédit développeur
    doc.text(
      'Solution développée par Digital Multi Services Guinee - Mamou',
      50, y + 35,
      { align: 'center', width: 500 }
    );
  }
}

module.exports = new PDFGenerator();