const { getDb } = require('../database/database');
const si = require('systeminformation');
const crypto = require('crypto');
const { APP_NAME, APP_VERSION } = require('../utils/constants');

class LicenceManager {
  
  // Générer une empreinte unique de la machine
  async generateMachineId() {
    try {
      const cpu = await si.cpu();
      const disk = await si.diskLayout();
      const system = await si.system();
      const uuid = await si.uuid();
      
      // Créer une empreinte unique basée sur le matériel
      const machineData = [
        cpu.manufacturer,
        cpu.brand,
        disk[0]?.serialNum || 'unknown',
        system.serial,
        uuid.os
      ].join('|');
      
      return crypto.createHash('sha256').update(machineData).digest('hex');
    } catch (error) {
      console.error('Erreur génération machine ID:', error);
      // Fallback: utiliser des infos système de base
      const fallbackData = [
        process.platform,
        process.arch,
        process.env.COMPUTERNAME || process.env.HOSTNAME || 'unknown'
      ].join('|');
      
      return crypto.createHash('sha256').update(fallbackData).digest('hex');
    }
  }
  
  // Vérifier si une licence est active
  async checkLicence() {
    const db = getDb();
    
    try {
      const licence = db.prepare('SELECT * FROM licence WHERE id = 1').get();
      
      if (!licence) {
        return { activated: false, message: 'Aucune licence trouvée' };
      }
      
      if (licence.statut !== 'active') {
        return { activated: false, message: 'Licence non active' };
      }
      
      // Vérifier que la machine correspond
      const currentMachineId = await this.generateMachineId();
      
      if (licence.machine_id !== currentMachineId) {
        return { 
          activated: false, 
          message: 'Cette licence est liée à une autre machine' 
        };
      }
      
      return { 
        activated: true, 
        licence: {
          cle: licence.cle_licence,
          date_activation: licence.date_activation,
          statut: licence.statut
        }
      };
      
    } catch (error) {
      console.error('Erreur vérification licence:', error);
      return { activated: false, message: 'Erreur lors de la vérification' };
    }
  }
  
  // Activer une licence
  async activateLicence(licenceKey) {
    const db = getDb();
    
    try {
      // Formater la clé (enlever les espaces, mettre en majuscules)
      const formattedKey = licenceKey.trim().toUpperCase();
      
      // TODO: Implémenter un algorithme de validation plus robuste
      // Pour l'instant, on utilise une validation simple basée sur un pattern
      if (!this.validateLicenceKey(formattedKey)) {
        return { 
          success: false, 
          message: 'Clé de licence invalide' 
        };
      }
      
      // Générer l'empreinte machine
      const machineId = await this.generateMachineId();
      
      // Vérifier si une licence existe déjà
      const existingLicence = db.prepare('SELECT * FROM licence WHERE id = 1').get();
      
      const now = new Date().toISOString();
      
      if (existingLicence) {
        // Mettre à jour la licence existante
        db.prepare(`
          UPDATE licence 
          SET cle_licence = ?, date_activation = ?, machine_id = ?, statut = ?
          WHERE id = 1
        `).run(formattedKey, now, machineId, 'active');
      } else {
        // Créer une nouvelle licence
        db.prepare(`
          INSERT INTO licence (id, cle_licence, date_activation, machine_id, statut)
          VALUES (1, ?, ?, ?, 'active')
        `).run(formattedKey, now, machineId);
      }
      
      return { 
        success: true, 
        message: 'Licence activée avec succès' 
      };
      
    } catch (error) {
      console.error('Erreur activation licence:', error);
      return { 
        success: false, 
        message: 'Erreur lors de l\'activation' 
      };
    }
  }
  
  // Valider le format de la clé de licence
  validateLicenceKey(key) {
    // Format attendu: Ouendeno2021SB10 ou similaire
    // Au moins 8 caractères, alphanumérique
    const pattern = /^[A-Za-z0-9]{8,30}$/;
    return pattern.test(key);
  }
  
  // Désactiver la licence
  async deactivateLicence() {
    const db = getDb();
    
    try {
      db.prepare('UPDATE licence SET statut = ? WHERE id = 1').run('inactive');
      return { success: true, message: 'Licence désactivée' };
    } catch (error) {
      console.error('Erreur désactivation licence:', error);
      return { success: false, message: 'Erreur lors de la désactivation' };
    }
  }
  
  // Obtenir les informations de la licence
  getLicenceInfo() {
    const db = getDb();
    
    try {
      const licence = db.prepare('SELECT * FROM licence WHERE id = 1').get();
      return licence || null;
    } catch (error) {
      console.error('Erreur récupération info licence:', error);
      return null;
    }
  }
}

module.exports = new LicenceManager();