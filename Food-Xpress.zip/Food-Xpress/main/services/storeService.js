const Store = require('electron-store');

// Configuration du store avec chiffrement
const schema = {
  session: {
    type: 'object',
    properties: {
      userId: { type: 'number' },
      username: { type: 'string' },
      role: { type: 'string' },
      nomComplet: { type: 'string' },
      loginTime: { type: 'string' }
    }
  },
  settings: {
    type: 'object',
    properties: {
      autoLogin: { type: 'boolean' },
      lastBackup: { type: 'string' }
    }
  }
};

const store = new Store({
  schema,
  encryptionKey: 'food-xpress-secure-key-2026', // À changer en production
  clearInvalidConfig: true
});

module.exports = store;