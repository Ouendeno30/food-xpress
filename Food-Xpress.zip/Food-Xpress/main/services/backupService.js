const fs = require('fs');
const path = require('path');
const { getDb } = require('../database/database');
const { ensureDir } = require('../utils/helpers');
const { BACKUP_REMINDER_DAYS } = require('../utils/constants');

class BackupService {
  
  constructor() {
    this.backupDir = path.join(process.cwd(), 'backups');
    ensureDir(this.backupDir);
  }
  
  // Créer une sauvegarde
  async createBackup(destinationPath = null) {
    try {
      const db = getDb();
      const dbPath = db.name; // Chemin du fichier de base de données
      
      // Générer le nom du fichier de sauvegarde
      const timestamp = new Date().toISOString().replace(/[-:]/g, '').split('.')[0].replace('T', '_');
      const backupName = `foodxpress_backup_${timestamp}.db`;
      
      let finalPath;
      if (destinationPath) {
        // Vérifier que le dossier de destination existe
        const destDir = path.dirname(destinationPath);
        if (!fs.existsSync(destDir)) {
          fs.mkdirSync(destDir, { recursive: true });
        }
        finalPath = path.join(destDir, backupName);
      } else {
        finalPath = path.join(this.backupDir, backupName);
      }
      
      // Copier le fichier de base de données
      fs.copyFileSync(dbPath, finalPath);
      
      // Créer un fichier de métadonnées
      const metadata = {
        date: new Date().toISOString(),
        version: '2.0.0',
        tables: this.getTablesInfo(),
        fileSize: fs.statSync(finalPath).size
      };
      
      const metadataPath = finalPath.replace('.db', '.json');
      fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2));
      
      return {
        success: true,
        path: finalPath,
        size: metadata.fileSize,
        message: `Sauvegarde créée avec succès : ${backupName}`
      };
      
    } catch (error) {
      console.error('Erreur sauvegarde:', error);
      return {
        success: false,
        message: 'Erreur lors de la création de la sauvegarde : ' + error.message
      };
    }
  }
  
  // Restaurer une sauvegarde
  async restoreBackup(backupPath) {
    try {
      const db = getDb();
      const dbPath = db.name;
      
      // Vérifier que le fichier de sauvegarde existe
      if (!fs.existsSync(backupPath)) {
        throw new Error('Fichier de sauvegarde non trouvé');
      }
      
      // Vérifier que c'est bien un fichier SQLite
      const ext = path.extname(backupPath).toLowerCase();
      if (ext !== '.db' && ext !== '.sqlite') {
        throw new Error('Le fichier n\'est pas une base de données SQLite valide');
      }
      
      // Créer une sauvegarde automatique de la base actuelle avant restauration
      const autoBackupPath = path.join(this.backupDir, `pre_restore_backup_${Date.now()}.db`);
      fs.copyFileSync(dbPath, autoBackupPath);
      
      // Fermer la connexion à la base de données
      await this.closeDatabase();
      
      // Attendre un peu pour s'assurer que la connexion est bien fermée
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Remplacer le fichier de base de données
      fs.copyFileSync(backupPath, dbPath);
      
      // Réinitialiser la connexion (sera recréée au prochain appel)
      console.log('✅ Base de données restaurée avec succès');
      
      return {
        success: true,
        autoBackupPath,
        message: 'Base de données restaurée avec succès'
      };
      
    } catch (error) {
      console.error('Erreur restauration:', error);
      return {
        success: false,
        message: 'Erreur lors de la restauration : ' + error.message
      };
    }
  }
  
  // Fermer la connexion à la base de données
  closeDatabase() {
    return new Promise((resolve) => {
      try {
        const db = getDb();
        if (db) {
          db.close();
        }
      } catch (error) {
        // Ignorer les erreurs de fermeture
      }
      resolve();
    });
  }
  
  // Obtenir la date de la dernière sauvegarde
  getLastBackupDate() {
    try {
      const files = fs.readdirSync(this.backupDir)
        .filter(f => f.endsWith('.db'))
        .map(f => {
          const stat = fs.statSync(path.join(this.backupDir, f));
          return {
            name: f,
            time: stat.mtime.getTime(),
            size: stat.size
          };
        })
        .sort((a, b) => b.time - a.time);
      
      if (files.length > 0) {
        return {
          exists: true,
          date: new Date(files[0].time).toISOString(),
          name: files[0].name,
          size: files[0].size
        };
      }
      
      return { exists: false };
      
    } catch (error) {
      console.error('Erreur lecture dernières sauvegardes:', error);
      return { exists: false, error: error.message };
    }
  }
  
  // Vérifier si une sauvegarde est nécessaire (pas de sauvegarde depuis X jours)
  isBackupNeeded() {
    const lastBackup = this.getLastBackupDate();
    
    if (!lastBackup.exists) {
      return true;
    }
    
    const lastDate = new Date(lastBackup.date);
    const now = new Date();
    const diffDays = Math.floor((now - lastDate) / (1000 * 60 * 60 * 24));
    
    return diffDays >= BACKUP_REMINDER_DAYS;
  }
  
  // Obtenir la liste des sauvegardes
  getBackupsList() {
    try {
      const files = fs.readdirSync(this.backupDir)
        .filter(f => f.endsWith('.db'))
        .map(f => {
          const filePath = path.join(this.backupDir, f);
          const stat = fs.statSync(filePath);
          const metadataPath = filePath.replace('.db', '.json');
          
          let metadata = null;
          if (fs.existsSync(metadataPath)) {
            try {
              metadata = JSON.parse(fs.readFileSync(metadataPath, 'utf8'));
            } catch (e) {
              // Ignorer les erreurs de métadonnées
            }
          }
          
          return {
            name: f,
            path: filePath,
            date: stat.mtime.toISOString(),
            size: stat.size,
            metadata
          };
        })
        .sort((a, b) => new Date(b.date) - new Date(a.date));
      
      return files;
      
    } catch (error) {
      console.error('Erreur lecture liste sauvegardes:', error);
      return [];
    }
  }
  
  // Obtenir des informations sur les tables
  getTablesInfo() {
    try {
      const db = getDb();
      const tables = db.prepare(`
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name NOT LIKE 'sqlite_%'
      `).all();
      
      const info = {};
      tables.forEach(table => {
        const count = db.prepare(`SELECT COUNT(*) as count FROM ${table.name}`).get();
        info[table.name] = count.count;
      });
      
      return info;
    } catch (error) {
      console.error('Erreur récupération info tables:', error);
      return {};
    }
  }
  
  // Supprimer une sauvegarde
  deleteBackup(backupPath) {
    try {
      if (fs.existsSync(backupPath)) {
        fs.unlinkSync(backupPath);
        
        // Supprimer aussi le fichier metadata s'il existe
        const metadataPath = backupPath.replace('.db', '.json');
        if (fs.existsSync(metadataPath)) {
          fs.unlinkSync(metadataPath);
        }
        
        return { success: true, message: 'Sauvegarde supprimée' };
      }
      return { success: false, message: 'Fichier non trouvé' };
    } catch (error) {
      console.error('Erreur suppression sauvegarde:', error);
      return { success: false, message: error.message };
    }
  }
}

module.exports = new BackupService();