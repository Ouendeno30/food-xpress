const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');

let db = null;

// Chemin de la base de données
const DB_PATH = path.join(__dirname, '../../database/foodxpress.db');
const DB_DIR = path.dirname(DB_PATH);

function initDatabase() {
  return new Promise((resolve, reject) => {
    try {
      // Créer le dossier database s'il n'existe pas
      if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
      }

      // Initialiser la connexion à la BDD
      db = new Database(DB_PATH, { verbose: console.log });
      db.pragma('foreign_keys = ON');

      console.log('📦 Connexion BDD établie');

      // Créer les tables
      createTables();

      resolve(db);
    } catch (error) {
      console.error('❌ Erreur initialisation BDD:', error);
      reject(error);
    }
  });
}

function createTables() {
  // Table utilisateurs
  db.exec(`
    CREATE TABLE IF NOT EXISTS utilisateurs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'vendeur',
      nom_complet TEXT NOT NULL,
      actif INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      last_login TEXT,
      login_attempts INTEGER DEFAULT 0
    )
  `);

  // Table categories
  db.exec(`
    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nom TEXT NOT NULL UNIQUE,
      description TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    )
  `);

  // Table produits
  db.exec(`
    CREATE TABLE IF NOT EXISTS produits (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reference TEXT NOT NULL UNIQUE,
      nom TEXT NOT NULL,
      categorie_id INTEGER,
      prix_achat REAL NOT NULL DEFAULT 0,
      prix_vente REAL NOT NULL DEFAULT 0,
      unite TEXT NOT NULL DEFAULT 'piece',
      stock_actuel REAL NOT NULL DEFAULT 0,
      seuil_alerte REAL NOT NULL DEFAULT 5,
      actif INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      FOREIGN KEY (categorie_id) REFERENCES categories(id)
    )
  `);

  // Table fournisseurs
  db.exec(`
    CREATE TABLE IF NOT EXISTS fournisseurs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nom TEXT NOT NULL,
      telephone TEXT,
      adresse TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    )
  `);

  // Table achats (entête)
  db.exec(`
    CREATE TABLE IF NOT EXISTS achats (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      numero_achat TEXT NOT NULL UNIQUE,
      fournisseur_id INTEGER,
      utilisateur_id INTEGER NOT NULL,
      date_achat TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      montant_total REAL NOT NULL DEFAULT 0,
      reference_bl TEXT,
      note TEXT,
      FOREIGN KEY (fournisseur_id) REFERENCES fournisseurs(id),
      FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id)
    )
  `);

  // Table achats_lignes (détail)
  db.exec(`
    CREATE TABLE IF NOT EXISTS achats_lignes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      achat_id INTEGER NOT NULL,
      produit_id INTEGER NOT NULL,
      quantite REAL NOT NULL,
      prix_achat_unitaire REAL NOT NULL,
      montant_ligne REAL NOT NULL,
      FOREIGN KEY (achat_id) REFERENCES achats(id),
      FOREIGN KEY (produit_id) REFERENCES produits(id)
    )
  `);

  // Table ventes (entête)
  db.exec(`
    CREATE TABLE IF NOT EXISTS ventes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      numero_facture TEXT NOT NULL UNIQUE,
      utilisateur_id INTEGER NOT NULL,
      client_nom TEXT,
      client_contact TEXT,
      date_vente TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      montant_total REAL NOT NULL DEFAULT 0,
      montant_paye REAL NOT NULL DEFAULT 0,
      monnaie_rendue REAL NOT NULL DEFAULT 0,
      pdf_path TEXT,
      FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id)
    )
  `);

  // Table ventes_lignes (détail)
  db.exec(`
    CREATE TABLE IF NOT EXISTS ventes_lignes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vente_id INTEGER NOT NULL,
      produit_id INTEGER NOT NULL,
      quantite REAL NOT NULL,
      prix_vente_unitaire REAL NOT NULL,
      montant_ligne REAL NOT NULL,
      FOREIGN KEY (vente_id) REFERENCES ventes(id),
      FOREIGN KEY (produit_id) REFERENCES produits(id)
    )
  `);

  // Table mouvements_stock (journal)
  db.exec(`
    CREATE TABLE IF NOT EXISTS mouvements_stock (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      produit_id INTEGER NOT NULL,
      type_mouvement TEXT NOT NULL,
      quantite REAL NOT NULL,
      stock_avant REAL NOT NULL,
      stock_apres REAL NOT NULL,
      reference_id INTEGER,
      utilisateur_id INTEGER NOT NULL,
      justification TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      FOREIGN KEY (produit_id) REFERENCES produits(id),
      FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id)
    )
  `);

  // Table licence
  db.exec(`
    CREATE TABLE IF NOT EXISTS licence (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      cle_licence TEXT NOT NULL,
      date_activation TEXT NOT NULL,
      machine_id TEXT NOT NULL,
      statut TEXT NOT NULL DEFAULT 'inactive'
    )
  `);

  // Table parametres_entreprise
  db.exec(`
    CREATE TABLE IF NOT EXISTS parametres_entreprise (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      nom TEXT NOT NULL DEFAULT 'FOOD XPRESS',
      logo TEXT,
      adresse TEXT,
      telephone TEXT,
      email TEXT,
      devise TEXT NOT NULL DEFAULT 'GNF',
      message_bas_facture TEXT DEFAULT 'Merci de votre confiance ! À bientôt chez FOOD XPRESS',
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    )
  `);

  // Insérer les paramètres par défaut si la table est vide
  const count = db.prepare('SELECT COUNT(*) as count FROM parametres_entreprise').get();
  if (count.count === 0) {
    db.prepare(`
      INSERT INTO parametres_entreprise (id, nom, devise, message_bas_facture)
      VALUES (1, 'FOOD XPRESS', 'GNF', 'Merci de votre confiance ! À bientôt chez FOOD XPRESS')
    `).run();
  }

  // Créer les index pour les performances
  createIndexes();

  console.log('✅ Tables créées/vérifiées');
}

function createIndexes() {
  // Index pour les recherches fréquentes
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_produits_categorie ON produits(categorie_id);
    CREATE INDEX IF NOT EXISTS idx_produits_reference ON produits(reference);
    CREATE INDEX IF NOT EXISTS idx_ventes_date ON ventes(date_vente);
    CREATE INDEX IF NOT EXISTS idx_ventes_numero ON ventes(numero_facture);
    CREATE INDEX IF NOT EXISTS idx_achats_date ON achats(date_achat);
    CREATE INDEX IF NOT EXISTS idx_mouvements_produit ON mouvements_stock(produit_id);
    CREATE INDEX IF NOT EXISTS idx_mouvements_date ON mouvements_stock(created_at);
    CREATE INDEX IF NOT EXISTS idx_utilisateurs_username ON utilisateurs(username);
  `);
  console.log('✅ Index créés');
}

function getDb() {
  if (!db) {
    throw new Error('Base de données non initialisée');
  }
  return db;
}

module.exports = {
  initDatabase,
  getDb
};