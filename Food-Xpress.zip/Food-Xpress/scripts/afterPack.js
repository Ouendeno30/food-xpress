const fs = require('fs');
const path = require('path');

exports.default = async function(context) {
  const { appOutDir, packager } = context;
  const appName = packager.appInfo.productName;
  
  console.log('📦 Configuration post-build...');
  
  // Créer les dossiers nécessaires dans l'installation
  const resourcesDir = path.join(appOutDir, 'resources');
  const dbDir = path.join(appOutDir, 'database');
  const invoicesDir = path.join(appOutDir, 'invoices');
  const backupsDir = path.join(appOutDir, 'backups');
  const supportDir = path.join(appOutDir, 'support_messages');
  
  [dbDir, invoicesDir, backupsDir, supportDir].forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log(`  ✅ Dossier créé: ${path.basename(dir)}`);
    }
  });
  
  // Copier les fichiers de ressources si nécessaire
  const sourceResources = path.join(process.cwd(), 'resources');
  const destResources = path.join(appOutDir, 'resources');
  
  if (fs.existsSync(sourceResources)) {
    // Fonction pour copier récursivement
    function copyRecursive(src, dest) {
      const exists = fs.existsSync(src);
      const stats = exists && fs.statSync(src);
      const isDirectory = exists && stats.isDirectory();
      
      if (isDirectory) {
        if (!fs.existsSync(dest)) {
          fs.mkdirSync(dest);
        }
        fs.readdirSync(src).forEach(childItemName => {
          copyRecursive(path.join(src, childItemName), path.join(dest, childItemName));
        });
      } else {
        fs.copyFileSync(src, dest);
      }
    }
    
    copyRecursive(sourceResources, destResources);
    console.log('  ✅ Ressources copiées');
  }
  
  // Créer un fichier README.txt dans le dossier d'installation
  const readmePath = path.join(appOutDir, 'LISEZ-MOI.txt');
  const readmeContent = `FOOD XPRESS - Application de Gestion

Version: 2.0.0
Date: Mars 2026
Client: FOOD XPRESS - Mamou, Guinée
Développeur: Digital Multi Services Guinee

INSTRUCTIONS D'INSTALLATION
---------------------------
1. Exécutez FOOD XPRESS Setup.exe
2. Suivez les instructions de l'installateur
3. Au premier lancement, activez votre licence
4. Créez le compte administrateur
5. Configurez les informations de l'entreprise

CONTACT SUPPORT
---------------
Ouendeno Saa Bernard
Tél/WhatsApp: +224 621 62 03 46
Email: ouendenosabernard@gmail.com
Site: https://ouendeno.vercel.app

© 2026 Digital Multi Services Guinee - Tous droits réservés
`;

  fs.writeFileSync(readmePath, readmeContent);
  console.log('  ✅ Fichier LISEZ-MOI créé');
  
  console.log('✅ Post-build terminé avec succès');
};