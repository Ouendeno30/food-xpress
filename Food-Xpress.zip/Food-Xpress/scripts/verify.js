const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🔍 Vérification pré-build de FOOD XPRESS');
console.log('========================================');

let errors = 0;
let warnings = 0;

// 1. Vérifier les dossiers nécessaires
console.log('\n📁 Vérification des dossiers...');
const requiredDirs = [
  'main',
  'main/database',
  'main/handlers',
  'main/services',
  'main/utils',
  'renderer',
  'renderer/assets/css',
  'renderer/assets/js',
  'renderer/assets/js/pages',
  'renderer/assets/lib',
  'renderer/assets/images',
  'renderer/pages',
  'renderer/pages/sales',
  'renderer/pages/stock',
  'renderer/pages/management',
  'renderer/pages/tools',
  'renderer/pages/support',
  'renderer/pages/system',
  'resources'
];

requiredDirs.forEach(dir => {
  if (!fs.existsSync(dir)) {
    console.log(`  ❌ Dossier manquant: ${dir}`);
    errors++;
  } else {
    console.log(`  ✅ Dossier présent: ${dir}`);
  }
});

// 2. Vérifier les fichiers critiques
console.log('\n📄 Vérification des fichiers critiques...');
const criticalFiles = [
  'package.json',
  'main/main.js',
  'main/preload.js',
  'main/database/database.js',
  'main/handlers/index.js',
  'renderer/pages/layout.html',
  'renderer/assets/css/main.css',
  'renderer/assets/js/renderer.js'
];

criticalFiles.forEach(file => {
  if (!fs.existsSync(file)) {
    console.log(`  ❌ Fichier critique manquant: ${file}`);
    errors++;
  } else {
    console.log(`  ✅ Fichier présent: ${file}`);
  }
});

// 3. Vérifier les dépendances dans package.json
console.log('\n📦 Vérification des dépendances...');
try {
  const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
  const requiredDeps = [
    'better-sqlite3',
    'bcryptjs',
    'electron-store',
    'pdfkit',
    'chart.js',
    'bootstrap',
    'systeminformation'
  ];
  
  requiredDeps.forEach(dep => {
    if (!packageJson.dependencies || !packageJson.dependencies[dep]) {
      console.log(`  ❌ Dépendance manquante: ${dep}`);
      errors++;
    } else {
      console.log(`  ✅ Dépendance présente: ${dep} (${packageJson.dependencies[dep]})`);
    }
  });
  
  // Vérifier les devDependencies
  const requiredDevDeps = ['electron', 'electron-builder', 'javascript-obfuscator'];
  requiredDevDeps.forEach(dep => {
    if (!packageJson.devDependencies || !packageJson.devDependencies[dep]) {
      console.log(`  ⚠️  Dev-dépendance manquante: ${dep}`);
      warnings++;
    } else {
      console.log(`  ✅ Dev-dépendance présente: ${dep}`);
    }
  });
  
} catch (error) {
  console.log(`  ❌ Erreur lecture package.json: ${error.message}`);
  errors++;
}

// 4. Vérifier la configuration electron-builder
console.log('\n🔧 Vérification de la configuration...');
if (fs.existsSync('electron-builder.yml')) {
  console.log('  ✅ electron-builder.yml présent');
} else if (fs.existsSync('electron-builder.json')) {
  console.log('  ✅ electron-builder.json présent');
} else {
  console.log('  ❌ Configuration electron-builder manquante');
  errors++;
}

// 5. Vérifier l'icône
console.log('\n🎨 Vérification des ressources...');
if (fs.existsSync('resources/icon.ico')) {
  console.log('  ✅ Icône présente');
} else {
  console.log('  ⚠️  Icône manquante (resources/icon.ico)');
  warnings++;
}

// 6. Vérifier la licence
if (fs.existsSync('resources/license.txt')) {
  console.log('  ✅ Fichier licence présent');
} else {
  console.log('  ⚠️  Fichier licence manquant');
  warnings++;
}

// 7. Vérifier Node.js et npm
console.log('\n🖥️  Vérification de l\'environnement...');
try {
  const nodeVersion = execSync('node --version').toString().trim();
  console.log(`  ✅ Node.js: ${nodeVersion}`);
} catch (error) {
  console.log(`  ❌ Node.js non trouvé`);
  errors++;
}

try {
  const npmVersion = execSync('npm --version').toString().trim();
  console.log(`  ✅ npm: ${npmVersion}`);
} catch (error) {
  console.log(`  ❌ npm non trouvé`);
  errors++;
}

// Résumé
console.log('\n========================================');
console.log(`📊 RÉSULTAT DE LA VÉRIFICATION`);
console.log(`   ❌ Erreurs: ${errors}`);
console.log(`   ⚠️  Avertissements: ${warnings}`);
console.log('========================================');

if (errors > 0) {
  console.log('\n❌ La vérification a échoué. Corrigez les erreurs avant de continuer.');
  process.exit(1);
} else {
  console.log('\n✅ Vérification réussie ! Prêt pour le build.\n');
  
  if (warnings > 0) {
    console.log('⚠️  Des avertissements ont été détectés (non bloquants).');
  }
  
  process.exit(0);
}