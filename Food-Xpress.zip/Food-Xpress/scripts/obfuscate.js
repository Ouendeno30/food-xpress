const JavaScriptObfuscator = require('javascript-obfuscator');
const fs = require('fs');
const path = require('path');
const glob = require('glob');

// Configuration de l'obfuscation
const obfuscationOptions = {
  compact: true,
  controlFlowFlattening: true,
  controlFlowFlatteningThreshold: 0.75,
  deadCodeInjection: true,
  deadCodeInjectionThreshold: 0.4,
  debugProtection: true,
  debugProtectionInterval: 2000,
  disableConsoleOutput: true,
  identifierNamesGenerator: 'hexadecimal',
  log: false,
  numbersToExpressions: true,
  renameGlobals: false,
  rotateStringArray: true,
  selfDefending: true,
  shuffleStringArray: true,
  splitStrings: true,
  splitStringsChunkLength: 10,
  stringArray: true,
  stringArrayEncoding: ['rc4'],
  stringArrayThreshold: 0.75,
  transformObjectKeys: true,
  unicodeEscapeSequence: false
};

// Fonction pour obfusquer un fichier
function obfuscateFile(filePath) {
  console.log(`🔒 Obfuscation de ${filePath}...`);
  
  try {
    const code = fs.readFileSync(filePath, 'utf8');
    const obfuscatedCode = JavaScriptObfuscator.obfuscate(code, obfuscationOptions).getObfuscatedCode();
    
    // Sauvegarder le fichier obfusqué
    const outputPath = filePath.replace('.js', '.obfuscated.js');
    fs.writeFileSync(outputPath, obfuscatedCode);
    
    // Remplacer l'original
    fs.renameSync(outputPath, filePath);
    
    console.log(`  ✅ Obfusqué avec succès`);
  } catch (error) {
    console.error(`  ❌ Erreur: ${error.message}`);
  }
}

// Fonction pour parcourir les dossiers
function obfuscateDirectory(directory) {
  const files = glob.sync(`${directory}/**/*.js`, {
    ignore: [
      '**/node_modules/**',
      '**/dist/**',
      '**/obfuscate.js',
      '**/*.min.js',
      '**/vendor/**'
    ]
  });
  
  console.log(`📦 ${files.length} fichiers JavaScript trouvés`);
  
  files.forEach(file => {
    obfuscateFile(file);
  });
}

// Exécution
console.log('🚀 Début de l\'obfuscation du code...');
console.log('=====================================');

// Obfusquer le dossier main
obfuscateDirectory('./main');

// Obfusquer les fichiers JS du renderer
obfuscateDirectory('./renderer/assets/js');

console.log('=====================================');
console.log('✅ Obfuscation terminée !');